/**
 * @file index.ts
 * @description Central TypeScript types and interfaces for the RecallMate AI application.
 * Defines data structures for flashcards, study decks, learning categories, quizzes, and analytics.
 */

// Difficulty levels for flashcard generation and quiz customization
export type DifficultyLevel = 'Beginner' | 'Intermediate' | 'Advanced';

// Question styles that guide the AI's content synthesis focus
export type QuestionStyle = 'Definitions' | 'Conceptual' | 'Formula-based' | 'Mixed';

/**
 * Flashcard learning categories based on active recall:
 * - 'unrecalled': The user could not remember the answer (replaces legacy 'forgot')
 * - 'practice': The user remembers the answer partially or needs more revision
 * - 'easy': The user remembers the answer confidently
 * - 'unreviewed': The card has not been classified yet (remains Unclassified)
 * - 'forgot': Supported for backward compatibility with previously stored browser data
 */
export type RecallRating = 'unrecalled' | 'practice' | 'easy' | 'unreviewed' | 'forgot';

// Supported card generation modes: Q&A questions, concept summaries, or a balanced mix
export type FlashcardTypeMode = 'qa' | 'concept' | 'both';

// Individual card representation type
export type CardType = 'qa' | 'concept';

// Input methods supported for generating flashcards
export type InputMode = 'topic' | 'pdf' | 'docx' | 'paste';

/**
 * Records an individual review attempt in the card's history
 */
export interface CardReviewEntry {
  // ISO timestamp of when the review took place
  date: string;
  // The recall classification assigned during this review
  rating: RecallRating;
}

/**
 * Represents a single flashcard within a study deck
 */
export interface Flashcard {
  // Unique identifier for the flashcard (e.g., 'card-17123456789-0')
  id: string;
  // Format of the card: 'qa' (Question & Answer) or 'concept' (Concept & Key Points)
  cardType?: CardType;
  // Front of card: The exam question or concept title
  question: string;
  // Back of card: The direct answer or concept definition
  answer: string;
  // Optional key bullet points for concept cards
  keyPoints?: string[];
  // Clear explanation or contextual memory aid for the student
  explanation: string;
  // Subtopic or subject module associated with this card
  topic: string;
  // Target difficulty rating assigned during generation
  difficulty: DifficultyLevel;
  // Optional direct text citation from the source notes or document
  sourceExcerpt?: string;
  // Number of times this card has been reviewed
  reviewsCount: number;
  // ISO timestamp of the most recent review, or null if unreviewed
  lastReviewedDate: string | null;
  // Current learning category classification
  recallRating: RecallRating;
  // Target date for next recommended spaced revision
  nextReviewDate: string | null;
  // Historical record of review classifications
  reviewHistory: CardReviewEntry[];
  // Current consecutive successful recall streak
  streak: number;
}

/**
 * Represents a saved flashcard deck created by the user
 */
export interface Deck {
  // Unique identifier for the deck
  id: string;
  // Human-readable title of the study deck
  title: string;
  // Academic subject or topic category (e.g., 'Biology', 'History')
  subject: string;
  // ISO timestamp when the deck was first created
  createdAt: string;
  // ISO timestamp of the last edit or card update
  updatedAt: string;
  // Raw source text or notes from which cards were synthesized
  sourceText?: string;
  // Original file name if created from a PDF, DOCX, or text file
  sourceFileName?: string;
  // Source topic if generated from a typed topic query
  sourceTopic?: string;
  // Generation mode used for this deck (concept, qa, or both)
  cardTypeMode?: FlashcardTypeMode;
  // Target difficulty level of the deck
  difficulty: DifficultyLevel;
  // The array of flashcards belonging to this deck
  cards: Flashcard[];
  // Flag indicating if this was a sample deck (legacy; purged in clean state)
  isSample?: boolean;
  // ISO timestamp of when the user last studied this deck via flashcards or quizzes
  lastStudiedAt?: string | null;
}

/**
 * Multiple-choice question synthesized by AI for interactive quiz mode
 */
export interface QuizQuestion {
  // Unique question identifier
  id: string;
  // Question prompt text
  question: string;
  // 4 answer options (e.g., ['A', 'B', 'C', 'D'])
  options: string[];
  // Zero-based index of the correct answer in the options array
  correctAnswerIndex: number;
  // Detailed explanation explaining why the answer is correct
  explanation: string;
  // Source reference or topic tag
  sourceReference?: string;
}

/**
 * Records a student's answer submission for a single quiz question
 */
export interface QuizUserAnswer {
  // Reference to the question answered
  questionId: string;
  // Text of the question answered
  questionText: string;
  // Zero-based index of the option chosen by the user
  selectedOptionIndex: number;
  // Zero-based index of the actual correct option
  correctOptionIndex: number;
  // Whether the user's choice matched the correct option
  isCorrect: boolean;
  // Explanation provided for the question
  explanation: string;
}

/**
 * Represents a completed quiz session saved to persistent history
 */
export interface QuizAttempt {
  // Unique attempt identifier
  id: string;
  // ID of the deck tested
  deckId: string;
  // Title of the deck tested
  deckTitle: string;
  // Academic subject of the deck
  subject: string;
  // ISO timestamp when the quiz was finished
  timestamp: string;
  // Total number of questions in the quiz
  totalQuestions: number;
  // Number of questions answered correctly
  correctAnswers: number;
  // Score percentage calculated as (correctAnswers / totalQuestions) * 100
  scorePercent: number;
  // Difficulty level selected for the quiz
  difficulty: DifficultyLevel;
  // Detailed breakdown of each user answer
  answers: QuizUserAnswer[];
}

/**
 * Aggregated learning analytics computed across all decks and quiz attempts
 */
export interface StudyStats {
  // Total number of decks created by the user
  totalDecks: number;
  // Total number of flashcards across all user decks
  totalCards: number;
  // Total number of cards that have been reviewed at least once
  totalCardsReviewed: number;
  // Total number of completed quizzes
  quizzesCompleted: number;
  // Average score percentage across all quiz sessions
  averageQuizScore: number;
  // Number of cards currently classified as 'Easy'
  easyCount: number;
  // Number of cards currently classified as 'Need Practice'
  practiceCount: number;
  // Number of cards currently classified as 'Unrecalled'
  unrecalledCount: number;
  // Number of cards currently classified as 'Unrecalled' (legacy alias)
  forgotCount?: number;
  // Number of cards that remain Unclassified
  unreviewedCount: number;
  // Number of cards due for spaced revision today
  cardsDueToday: number;
}

/**
 * Item structure for recently studied topics displayed on the dashboard
 */
export interface RecentlyStudiedTopic {
  // Reference to the studied deck
  deck: Deck;
  // Name of the topic or deck
  topicName: string;
  // ISO timestamp or formatted time of the latest study activity
  lastStudiedDate: string;
  // Type of study activity: flashcards review or quiz
  activityType: 'flashcards' | 'quiz';
  // Breakdown of active category counts for this deck
  categoryCounts: {
    unrecalled: number;
    practice: number;
    easy: number;
    unclassified: number;
  };
}

/**
 * Item structure for personalized study recommendations on the dashboard
 */
export interface StudyRecommendation {
  // Reference to the recommended deck
  deck: Deck;
  // Topic or deck title
  topicName: string;
  // Short pedagogical rationale for why this topic is recommended
  description: string;
  // Priority indicator for visual accentuation
  priority: 'high' | 'medium' | 'low';
  // Category filter to open directly if focused on unrecalled cards
  recommendedCategory?: 'unrecalled' | 'practice' | 'all';
}
