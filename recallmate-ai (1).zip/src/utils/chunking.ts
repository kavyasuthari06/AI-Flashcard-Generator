/**
 * @file chunking.ts
 * @description Document chunking and deduplication utility for large study materials.
 * Splits large PDF, DOCX, or text files into manageable segments at natural boundaries
 * (page demarcations, section breaks, or paragraph breaks) and removes duplicate flashcards.
 */

import { Flashcard } from '../types';

/**
 * Splits large document text into manageable chunks.
 * Preserves page tags like [Page 1] and avoids splitting sentences mid-thought.
 * 
 * @param text - The full extracted document text.
 * @param maxCharsPerChunk - Maximum characters allowed per chunk (default 12,000 chars, ~2,500 words).
 * @returns Array of text chunk strings.
 */
export function splitTextIntoChunks(text: string, maxCharsPerChunk: number = 12000): string[] {
  const trimmed = text.trim();
  if (trimmed.length <= maxCharsPerChunk) {
    return [trimmed];
  }

  const chunks: string[] = [];

  // 1. If the text has [Page X] tags from PDF extraction, attempt to chunk by pages
  if (trimmed.includes('[Page ')) {
    const pageBlocks = trimmed.split(/(?=\[Page \d+\])/g);
    let currentChunk = '';

    for (const block of pageBlocks) {
      if ((currentChunk + block).length > maxCharsPerChunk && currentChunk.length > 0) {
        chunks.push(currentChunk.trim());
        currentChunk = block;
      } else {
        currentChunk += block;
      }
    }

    if (currentChunk.trim().length > 0) {
      chunks.push(currentChunk.trim());
    }

    if (chunks.length > 0) {
      return chunks;
    }
  }

  // 2. Fall back to paragraph-based splitting
  const paragraphs = trimmed.split(/\n\s*\n/);
  let currentParagraphChunk = '';

  for (const para of paragraphs) {
    if ((currentParagraphChunk + '\n\n' + para).length > maxCharsPerChunk && currentParagraphChunk.length > 0) {
      chunks.push(currentParagraphChunk.trim());
      currentParagraphChunk = para;
    } else {
      currentParagraphChunk = currentParagraphChunk.length === 0 ? para : currentParagraphChunk + '\n\n' + para;
    }
  }

  if (currentParagraphChunk.trim().length > 0) {
    chunks.push(currentParagraphChunk.trim());
  }

  // 3. If any chunk is still larger than maxCharsPerChunk, divide at sentence boundaries
  const refinedChunks: string[] = [];
  for (const chunk of chunks) {
    if (chunk.length <= maxCharsPerChunk) {
      refinedChunks.push(chunk);
    } else {
      const sentences = chunk.match(/[^.!?]+[.!?]+(\s+|$)/g) || [chunk];
      let subChunk = '';
      for (const sent of sentences) {
        if ((subChunk + sent).length > maxCharsPerChunk && subChunk.length > 0) {
          refinedChunks.push(subChunk.trim());
          subChunk = sent;
        } else {
          subChunk += sent;
        }
      }
      if (subChunk.trim().length > 0) {
        refinedChunks.push(subChunk.trim());
      }
    }
  }

  return refinedChunks.length > 0 ? refinedChunks : [trimmed];
}

/**
 * Normalizes question strings for duplicate detection:
 * Lowercases, strips punctuation, and collapses white space.
 * 
 * @param question - The question text to normalize.
 * @returns Normalized string for comparison.
 */
function normalizeQuestion(question: string): string {
  return question
    .toLowerCase()
    .replace(/[^\w\s]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Deduplicates flashcards across multiple chunk responses.
 * Compares normalized questions to ensure students do not see repetitive cards.
 * 
 * @param cards - Array of generated Flashcards across chunks.
 * @returns Array of unique Flashcards.
 */
export function deduplicateCards(cards: Flashcard[]): Flashcard[] {
  const seenQuestions = new Set<string>();
  const uniqueCards: Flashcard[] = [];

  for (const card of cards) {
    const key = normalizeQuestion(card.question);
    if (!key || seenQuestions.has(key)) {
      continue;
    }
    seenQuestions.add(key);
    uniqueCards.push(card);
  }

  return uniqueCards;
}
