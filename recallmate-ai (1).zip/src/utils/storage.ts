/**
 * @file storage.ts
 * @description Persistent browser storage and spaced-revision state manager for RecallMate AI.
 * Handles loading, saving, updating, and deleting study decks, individual flashcards,
 * category classifications (Unrecalled, Need Practice, Easy), and quiz attempt history.
 * All operations persist directly to browser localStorage.
 */

import {
  Deck,
  Flashcard,
  QuizAttempt,
  RecallRating,
  RecentlyStudiedTopic,
  StudyRecommendation,
  StudyStats,
} from '../types';

// LocalStorage key for storing user flashcard decks
const DECKS_KEY = 'recallmate_decks';

// LocalStorage key for storing quiz session attempts
const QUIZ_HISTORY_KEY = 'recallmate_quiz_history';

/**
 * Normalizes legacy recall ratings to current standards:
 * Maps legacy 'forgot' to the new 'unrecalled' category label.
 * 
 * @param rating - The rating value from storage or component state.
 * @returns Normalized RecallRating ('unrecalled', 'practice', 'easy', or 'unreviewed').
 */
export function normalizeRating(rating?: string | null): 'unrecalled' | 'practice' | 'easy' | 'unreviewed' {
  // [CLEAR LINE COMMENT]: Early guard clause clearly handles missing, null, or unreviewed ratings
  if (!rating || rating === 'unreviewed') return 'unreviewed';
  // [CLEAR LINE COMMENT]: Clearly migrates legacy 'forgot' rating to the standardized 'unrecalled' label
  if (rating === 'forgot' || rating === 'unrecalled') return 'unrecalled';
  // [CLEAR LINE COMMENT]: Direct equality checks clearly preserve valid category strings
  if (rating === 'practice') return 'practice';
  if (rating === 'easy') return 'easy';
  return 'unreviewed'; // Safe default fallback
}

/**
 * Initializes persistent storage and purges any legacy demo or sample decks
 * to ensure students begin with a completely fresh, user-driven workspace.
 */
export function initializeStorage(): void {
  try {
    const existing = localStorage.getItem(DECKS_KEY);
    if (existing) {
      const parsed = JSON.parse(existing);
      if (Array.isArray(parsed)) {
        // Filter out any legacy preloaded sample decks
        const cleanUserDecks = parsed
          .filter((d: any) => !d.isSample && !String(d.id || '').startsWith('sample-'))
          .map((d: any) => ({
            ...d,
            cards: Array.isArray(d.cards)
              ? d.cards.map((c: any) => ({
                  ...c,
                  // Ensure all cards use normalized 'unrecalled' category instead of 'forgot'
                  recallRating: normalizeRating(c.recallRating),
                }))
              : [],
          }));
        localStorage.setItem(DECKS_KEY, JSON.stringify(cleanUserDecks));
      }
    }
  } catch (error) {
    console.error('Storage initialization cleanup error:', error);
  }
}

/**
 * Retrieves all user-created flashcard decks from localStorage.
 * Automatically normalizes ratings and ensures sample decks are excluded.
 * 
 * @returns Array of Deck objects belonging to the user.
 */
export function getDecks(): Deck[] {
  try {
    const rawData = localStorage.getItem(DECKS_KEY);
    if (!rawData) return [];

    const parsed = JSON.parse(rawData);
    if (!Array.isArray(parsed)) return [];

    // Return only genuine user decks with normalized card categories
    return parsed
      .filter((d: any) => !d.isSample && !String(d.id || '').startsWith('sample-'))
      .map((d: any) => ({
        ...d,
        cards: Array.isArray(d.cards)
          ? d.cards.map((c: any) => ({
              ...c,
              recallRating: normalizeRating(c.recallRating),
            }))
          : [],
      }));
  } catch (error) {
    console.error('Failed to parse decks from localStorage:', error);
    return [];
  }
}

/**
 * Persists an array of decks to localStorage.
 * 
 * @param decks - Array of Deck objects to save.
 */
export function saveDecks(decks: Deck[]): void {
  try {
    // Filter to ensure no demo or sample decks are saved
    const userOnly = decks.filter(
      (d: any) => !d.isSample && !String(d.id || '').startsWith('sample-')
    );
    localStorage.setItem(DECKS_KEY, JSON.stringify(userOnly));
  } catch (error) {
    console.error('Failed to save decks to localStorage:', error);
  }
}

/**
 * Finds and returns a specific deck by its unique ID.
 * 
 * @param deckId - The unique ID of the deck to look up.
 * @returns The matching Deck or undefined if not found.
 */
export function getDeckById(deckId: string): Deck | undefined {
  const decks = getDecks();
  return decks.find((d) => d.id === deckId);
}

/**
 * Saves a new deck or updates an existing deck in persistent storage.
 * 
 * @param updatedDeck - The Deck object with updated content or metadata.
 */
export function saveDeck(updatedDeck: Deck): void {
  const decks = getDecks();
  const cleanDeck = { ...updatedDeck, isSample: false };
  const existingIndex = decks.findIndex((d) => d.id === cleanDeck.id);

  if (existingIndex >= 0) {
    // Update existing deck in place
    decks[existingIndex] = { ...cleanDeck, updatedAt: new Date().toISOString() };
  } else {
    // Add newly created deck to the beginning of the list
    decks.unshift({ ...cleanDeck, updatedAt: new Date().toISOString() });
  }

  saveDecks(decks);
}

/**
 * Deletes an entire deck and all its associated flashcards from persistent storage.
 * 
 * @param deckId - The ID of the deck to permanently remove.
 */
export function deleteDeck(deckId: string): void {
  const currentDecks = getDecks();
  const remainingDecks = currentDecks.filter((d) => d.id !== deckId);
  saveDecks(remainingDecks);
}

/**
 * Deletes one or multiple specific flashcards from a deck by their card IDs.
 * Immediately updates the deck and persistent storage.
 * 
 * @param deckId - ID of the deck containing the cards.
 * @param cardIds - Array of card IDs to delete from the deck.
 * @returns The updated Deck object, or null if the deck was not found.
 */
export function deleteCardsFromDeck(deckId: string, cardIds: string[]): Deck | null {
  const decks = getDecks();
  const targetDeck = decks.find((d) => d.id === deckId);
  if (!targetDeck) return null;

  // Convert card IDs to a Set for O(1) membership lookup
  const idsToDelete = new Set(cardIds);

  // Filter out the selected cards from the deck's card array
  targetDeck.cards = targetDeck.cards.filter((card) => !idsToDelete.has(card.id));
  targetDeck.updatedAt = new Date().toISOString();

  // Save changes to persistent storage
  saveDeck(targetDeck);

  return targetDeck;
}

/**
 * Accurately calculates the category breakdown for a single deck:
 * - Unrecalled: Cards the user could not remember
 * - Need Practice: Cards the user partially remembered
 * - Easy: Cards the user remembered confidently
 * - Unclassified: New cards not yet reviewed
 * 
 * Rule: Unclassified cards are NOT included in the three active category counts.
 * 
 * @param deck - The Deck object to inspect.
 * @returns Category counts object with exact numbers.
 */
export function getDeckCategoryCounts(deck: Deck): {
  unrecalled: number;
  practice: number;
  easy: number;
  unclassified: number;
} {
  let unrecalled = 0;
  let practice = 0;
  let easy = 0;
  let unclassified = 0;

  for (const card of deck.cards) {
    const rating = normalizeRating(card.recallRating);
    if (rating === 'unrecalled') {
      unrecalled++;
    } else if (rating === 'practice') {
      practice++;
    } else if (rating === 'easy') {
      easy++;
    } else {
      unclassified++;
    }
  }

  return { unrecalled, practice, easy, unclassified };
}

/**
 * Updates a flashcard's learning category classification.
 * Rule: A card must belong to exactly one category.
 * Moving a card removes it from the previous category and adds it to the new one.
 * 
 * @param deckId - The ID of the deck containing the card.
 * @param cardId - The unique ID of the card being updated.
 * @param newRating - The new category: 'unrecalled', 'practice', or 'easy'.
 * @returns Updated deck and card objects, or null if not found.
 */
export function updateCardCategory(
  deckId: string,
  cardId: string,
  newRating: RecallRating
): { updatedDeck: Deck; updatedCard: Flashcard } | null {
  const decks = getDecks();
  const deck = decks.find((d) => d.id === deckId);
  if (!deck) return null;

  const cardIndex = deck.cards.findIndex((c) => c.id === cardId);
  if (cardIndex === -1) return null;

  const card = deck.cards[cardIndex];
  const normalizedNewRating = normalizeRating(newRating);
  const now = new Date();

  // Calculate next spaced revision date based on category classification
  let nextDate = new Date();
  let newStreak = card.streak || 0;

  if (normalizedNewRating === 'unrecalled') {
    // Reset streak and schedule for immediate review today
    newStreak = 0;
    nextDate = new Date(now.getTime() + 10 * 60 * 1000); // 10 minutes from now
  } else if (normalizedNewRating === 'practice') {
    // Schedule for next-day review
    newStreak = Math.max(1, newStreak);
    nextDate = new Date(now.getTime() + 24 * 60 * 60 * 1000); // 24 hours
  } else if (normalizedNewRating === 'easy') {
    // Increase streak and apply progressive spaced repetition interval
    newStreak += 1;
    const intervalDays = newStreak === 1 ? 3 : newStreak === 2 ? 7 : newStreak === 3 ? 14 : 30;
    nextDate = new Date(now.getTime() + intervalDays * 24 * 60 * 60 * 1000);
  }

  // Update card record with new category and review timestamp
  const updatedCard: Flashcard = {
    ...card,
    recallRating: normalizedNewRating,
    lastReviewedDate: now.toISOString(),
    nextReviewDate: nextDate.toISOString(),
    reviewsCount: (card.reviewsCount || 0) + 1,
    streak: newStreak,
    reviewHistory: [
      ...(card.reviewHistory || []),
      { date: now.toISOString(), rating: normalizedNewRating },
    ],
  };

  // Update deck record and mark last studied timestamp
  deck.cards[cardIndex] = updatedCard;
  deck.lastStudiedAt = now.toISOString();
  deck.updatedAt = now.toISOString();

  // Save to persistent storage
  saveDeck(deck);

  return { updatedDeck: deck, updatedCard };
}

/**
 * Retrieves recently studied topics based on genuine user activity.
 * Inspects decks with recorded study timestamps and quiz session history.
 * Does not generate fake or placeholder activity.
 * 
 * @returns Array of RecentlyStudiedTopic objects ordered by latest study time.
 */
export function getRecentlyStudiedTopics(): RecentlyStudiedTopic[] {
  const decks = getDecks();
  const quizHistory = getQuizHistory();
  const resultsMap = new Map<string, RecentlyStudiedTopic>();

  // 1. Check decks with recorded flashcard study timestamps
  for (const deck of decks) {
    if (deck.lastStudiedAt) {
      const counts = getDeckCategoryCounts(deck);
      resultsMap.set(deck.id, {
        deck,
        topicName: deck.title,
        lastStudiedDate: deck.lastStudiedAt,
        activityType: 'flashcards',
        categoryCounts: counts,
      });
    }
  }

  // 2. Cross-reference with quiz attempt history for the most recent study activity
  for (const attempt of quizHistory) {
    const deck = decks.find((d) => d.id === attempt.deckId);
    if (deck) {
      const existing = resultsMap.get(deck.id);
      const attemptTime = new Date(attempt.timestamp).getTime();
      const existingTime = existing ? new Date(existing.lastStudiedDate).getTime() : 0;

      // Update if quiz attempt is newer than flashcard study time
      if (!existing || attemptTime > existingTime) {
        const counts = getDeckCategoryCounts(deck);
        resultsMap.set(deck.id, {
          deck,
          topicName: deck.title,
          lastStudiedDate: attempt.timestamp,
          activityType: 'quiz',
          categoryCounts: counts,
        });
      }
    }
  }

  // Convert map to array and sort descending by study timestamp (most recent first)
  return Array.from(resultsMap.values()).sort(
    (a, b) => new Date(b.lastStudiedDate).getTime() - new Date(a.lastStudiedDate).getTime()
  );
}

/**
 * Generates personalized study recommendations based strictly on the user's
 * actual decks, category classifications, and study history.
 * Never outputs fake or demo decks.
 * 
 * @returns Array of StudyRecommendation objects tailored to the student.
 */
export function getStudyRecommendations(): StudyRecommendation[] {
  const decks = getDecks();
  if (decks.length === 0) return [];

  const recommendations: StudyRecommendation[] = [];

  for (const deck of decks) {
    const counts = getDeckCategoryCounts(deck);

    // Recommendation Rule 1: High priority if deck has Unrecalled cards
    if (counts.unrecalled > 0) {
      recommendations.push({
        deck,
        topicName: deck.title,
        description: `You have ${counts.unrecalled} unrecalled ${
          counts.unrecalled === 1 ? 'card' : 'cards'
        } in this deck. Reviewing them now will reinforce concepts before you forget.`,
        priority: 'high',
        recommendedCategory: 'unrecalled',
      });
      continue;
    }

    // Recommendation Rule 2: Medium priority if deck has cards marked Need Practice
    if (counts.practice > 0) {
      recommendations.push({
        deck,
        topicName: deck.title,
        description: `You have ${counts.practice} ${
          counts.practice === 1 ? 'card' : 'cards'
        } marked "Need Practice". Another review session will transition them to long-term memory.`,
        priority: 'medium',
        recommendedCategory: 'practice',
      });
      continue;
    }

    // Recommendation Rule 3: Decks that have never been studied or have unclassified cards
    if (!deck.lastStudiedAt || counts.unclassified > 0) {
      recommendations.push({
        deck,
        topicName: deck.title,
        description: `This deck contains ${deck.cards.length} cards ready to study. Begin reviewing to build your foundation in ${deck.subject}.`,
        priority: 'medium',
        recommendedCategory: 'all',
      });
      continue;
    }

    // Recommendation Rule 4: Regular refresher for older mastered decks
    const daysSinceStudied = (Date.now() - new Date(deck.lastStudiedAt).getTime()) / (1000 * 60 * 60 * 24);
    if (daysSinceStudied >= 2) {
      recommendations.push({
        deck,
        topicName: deck.title,
        description: `Last studied ${Math.round(daysSinceStudied)} days ago. A quick recall check will ensure retention stays sharp.`,
        priority: 'low',
        recommendedCategory: 'all',
      });
    }
  }

  // Sort recommendations: High priority first, then medium, then low
  const priorityWeights = { high: 3, medium: 2, low: 1 };
  return recommendations.sort(
    (a, b) => priorityWeights[b.priority] - priorityWeights[a.priority]
  );
}

/**
 * Retrieves completed quiz session history from localStorage.
 * 
 * @returns Array of QuizAttempt objects.
 */
export function getQuizHistory(): QuizAttempt[] {
  try {
    const rawData = localStorage.getItem(QUIZ_HISTORY_KEY);
    if (!rawData) return [];
    const parsed = JSON.parse(rawData);
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('Failed to parse quiz history:', error);
    return [];
  }
}

/**
 * Saves a completed quiz attempt to localStorage.
 * 
 * @param attempt - The completed QuizAttempt record.
 */
export function saveQuizAttempt(attempt: QuizAttempt): void {
  try {
    const history = getQuizHistory();
    history.unshift(attempt);
    // Keep the most recent 50 quiz attempts to prevent storage bloat
    localStorage.setItem(QUIZ_HISTORY_KEY, JSON.stringify(history.slice(0, 50)));
  } catch (error) {
    console.error('Failed to save quiz attempt:', error);
  }
}

/**
 * Calculates global study statistics across all user decks and quizzes.
 * 
 * @returns Aggregated StudyStats object.
 */
export function computeStats(): StudyStats {
  const decks = getDecks();
  const quizHistory = getQuizHistory();

  let totalCards = 0;
  let totalCardsReviewed = 0;
  let easyCount = 0;
  let practiceCount = 0;
  let unrecalledCount = 0;
  let unreviewedCount = 0;

  for (const deck of decks) {
    for (const card of deck.cards) {
      totalCards++;
      if (card.reviewsCount > 0) {
        totalCardsReviewed++;
      }

      const rating = normalizeRating(card.recallRating);
      if (rating === 'easy') easyCount++;
      else if (rating === 'practice') practiceCount++;
      else if (rating === 'unrecalled') unrecalledCount++;
      else unreviewedCount++;
    }
  }

  const quizzesCompleted = quizHistory.length;
  const averageQuizScore =
    quizzesCompleted > 0
      ? Math.round(
          quizHistory.reduce((acc, curr) => acc + (curr.scorePercent || 0), 0) / quizzesCompleted
        )
      : 0;

  return {
    totalDecks: decks.length,
    totalCards,
    totalCardsReviewed,
    quizzesCompleted,
    averageQuizScore,
    easyCount,
    practiceCount,
    unrecalledCount,
    forgotCount: unrecalledCount, // Legacy alias for backward compatibility
    unreviewedCount,
    cardsDueToday: unrecalledCount + practiceCount,
  };
}

/**
 * Clears all stored user decks and quiz history from localStorage.
 */
export function clearAllData(): void {
  localStorage.removeItem(DECKS_KEY);
  localStorage.removeItem(QUIZ_HISTORY_KEY);
}

/**
 * Exports all user decks and quiz attempts as a formatted JSON string for backup.
 * 
 * @returns JSON string representation of all application state.
 */
export function exportAllData(): string {
  return JSON.stringify(
    {
      appName: 'RecallMate AI',
      exportedAt: new Date().toISOString(),
      decks: getDecks(),
      quizHistory: getQuizHistory(),
    },
    null,
    2
  );
}

/**
 * Backward compatibility alias for updateCardCategory.
 */
export const updateCardRecallRating = updateCardCategory;

/**
 * Returns cards that need priority revision (Unrecalled or Need Practice).
 */
export function getDueRevisionCards(): { card: Flashcard; deck: Deck; reason: string }[] {
  const decks = getDecks();
  const dueList: { card: Flashcard; deck: Deck; reason: string }[] = [];
  const now = new Date();

  decks.forEach((deck) => {
    deck.cards.forEach((card) => {
      const rating = normalizeRating(card.recallRating);
      if (rating === 'unrecalled') {
        dueList.push({ card, deck, reason: 'Unrecalled — high priority' });
      } else if (rating === 'practice') {
        dueList.push({ card, deck, reason: 'Need practice' });
      } else if (card.nextReviewDate && new Date(card.nextReviewDate) <= now) {
        dueList.push({ card, deck, reason: 'Due for spaced review' });
      }
    });
  });

  return dueList;
}

