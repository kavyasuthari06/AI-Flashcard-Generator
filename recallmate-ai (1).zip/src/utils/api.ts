/**
 * @file api.ts
 * @description Client-side API caller for interacting with the backend Gemini endpoints.
 * Handles single-request flashcard generation, multi-chunk processing for large documents,
 * interactive quiz question synthesis, and server health checks.
 */

import {
  DifficultyLevel,
  Flashcard,
  FlashcardTypeMode,
  InputMode,
  QuestionStyle,
  QuizQuestion,
} from '../types';
import { deduplicateCards, splitTextIntoChunks } from './chunking';

/**
 * Payload interface sent to the backend for flashcard generation
 */
export interface GenerateCardsPayload {
  // Provided notes or document text
  content?: string;
  // Selected input method: 'topic', 'pdf', 'docx', or 'paste'
  inputMode?: InputMode;
  // Specific study topic query
  topic?: string;
  // Card format mode: 'qa', 'concept', or 'both'
  cardTypeMode?: FlashcardTypeMode;
  // Target number of cards to produce
  count: number;
  // Difficulty target
  difficulty: DifficultyLevel;
  // Question style guide
  style: QuestionStyle;
  // Academic subject
  subject: string;
  // Title for the resulting deck
  deckTitle: string;
  // Optional progress callback for large document multi-chunk feedback
  onProgress?: (stepMessage: string, percent: number) => void;
}

/**
 * Payload interface for generating multiple-choice quiz questions
 */
export interface GenerateQuizPayload {
  // Title of the deck being quizzed
  deckTitle: string;
  // Subject category of the deck
  subject: string;
  // Flashcards from which questions should be synthesized
  cards: Flashcard[];
  // Original source text for deeper context
  sourceNotes?: string;
  // Desired number of questions
  questionCount: number;
  // Target difficulty
  difficulty: DifficultyLevel;
}

/**
 * Sends a single chunk of text or topic query to the backend endpoint.
 * 
 * @param payload - Subset of parameters needed for a single API request.
 * @returns Promise resolving to an array of generated Flashcards.
 */
async function callSingleGenerateRequest(payload: {
  content: string;
  inputMode: InputMode;
  topic?: string;
  cardTypeMode: FlashcardTypeMode;
  count: number;
  difficulty: DifficultyLevel;
  style: QuestionStyle;
  subject: string;
  deckTitle: string;
}): Promise<Flashcard[]> {
  const response = await fetch('/api/generate-flashcards', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Failed to generate flashcards from server.');
  }

  return data.cards || [];
}

/**
 * Primary function to request flashcard generation from Gemini AI.
 * Handles large documents by chunking them into segments, processing segments,
 * deduplicating cards, and combining the results into a cohesive deck.
 * 
 * @param payload - Full generation parameters and optional progress listener.
 * @returns Promise resolving to the final set of generated Flashcards.
 */
export async function requestFlashcardGeneration(payload: GenerateCardsPayload): Promise<Flashcard[]> {
  const {
    content = '',
    inputMode = 'paste',
    topic,
    cardTypeMode = 'both',
    count = 10,
    difficulty = 'Intermediate',
    style = 'Mixed',
    subject = 'General',
    deckTitle = 'Study Deck',
    onProgress,
  } = payload;

  // If generating from a topic query, a single API request is sufficient
  if (inputMode === 'topic' || content.length <= 14000) {
    if (onProgress) {
      onProgress('Synthesizing study points with Gemini AI...', 50);
    }

    return await callSingleGenerateRequest({
      content,
      inputMode,
      topic,
      cardTypeMode,
      count,
      difficulty,
      style,
      subject,
      deckTitle,
    });
  }

  // --- Large Document Processing: Chunking & Combination ---
  // Split the large document text at natural page or paragraph boundaries
  const chunks = splitTextIntoChunks(content, 14000);
  const totalChunks = chunks.length;

  if (onProgress) {
    onProgress(`Divided large document into ${totalChunks} chunks for processing...`, 15);
  }

  // Calculate cards requested per chunk so total cards meet user requirement
  const cardsPerChunk = Math.max(3, Math.ceil(count / totalChunks));
  const accumulatedCards: Flashcard[] = [];

  // Process chunks sequentially to preserve order and avoid rate-limit bursts
  for (let i = 0; i < totalChunks; i++) {
    const chunkText = chunks[i];
    const chunkNumber = i + 1;
    const progressPercent = Math.round(15 + (chunkNumber / totalChunks) * 75);

    if (onProgress) {
      onProgress(`Processing segment ${chunkNumber} of ${totalChunks}...`, progressPercent);
    }

    try {
      const chunkCards = await callSingleGenerateRequest({
        content: chunkText,
        inputMode,
        topic,
        cardTypeMode,
        count: cardsPerChunk,
        difficulty,
        style,
        subject,
        deckTitle: `${deckTitle} (Part ${chunkNumber})`,
      });

      accumulatedCards.push(...chunkCards);
    } catch (chunkError) {
      console.warn(`Error processing chunk ${chunkNumber}:`, chunkError);
      // If we already collected some cards from previous chunks, continue gracefully
      if (accumulatedCards.length === 0 && i === totalChunks - 1) {
        throw chunkError;
      }
    }
  }

  if (onProgress) {
    onProgress('Deduplicating questions and assembling final deck...', 95);
  }

  // Deduplicate overlapping questions generated across boundaries
  const uniqueCards = deduplicateCards(accumulatedCards);

  // Return up to the requested card count (or all generated if fewer)
  return uniqueCards.slice(0, Math.max(count, uniqueCards.length));
}

/**
 * Requests multiple-choice quiz questions synthesized from deck flashcards.
 * 
 * @param payload - Deck information, cards, and desired question count.
 * @returns Promise resolving to an array of QuizQuestion objects.
 */
export async function requestQuizGeneration(payload: GenerateQuizPayload): Promise<QuizQuestion[]> {
  const response = await fetch('/api/generate-quiz', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.error || 'Failed to generate quiz questions.');
  }

  return data.questions || [];
}

/**
 * Checks server health and verifies that the Gemini API key is configured.
 * 
 * @returns Promise resolving to status and key presence.
 */
export async function checkServerStatus(): Promise<{ status: string; hasApiKey: boolean }> {
  try {
    const res = await fetch('/api/health');
    return await res.json();
  } catch {
    return { status: 'offline', hasApiKey: false };
  }
}
