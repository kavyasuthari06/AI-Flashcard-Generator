import { Deck } from '../types';

// Empty default: no pre-populated sample decks as requested.
export const SAMPLE_DECKS: Deck[] = [];
