/**
 * @file pdfExtractor.ts
 * @description Client-side PDF text extraction utility using pdfjs-dist.
 * Extracts selectable text from uploaded PDF documents directly in the browser,
 * retaining page demarcation tags (e.g., [Page 1], [Page 2]) for source citations.
 */

import * as pdfjsLib from 'pdfjs-dist';

// Configure the worker source using a reliable CDN that matches pdfjs-dist
try {
  if (typeof window !== 'undefined') {
    const version = pdfjsLib.version || '4.10.38';
    pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${version}/pdf.worker.min.mjs`;
  }
} catch (error) {
  console.warn('PDF worker configuration warning:', error);
}

/**
 * Result structure returned after successful PDF text extraction
 */
export interface ExtractedPdfResult {
  // Extracted plain text content with page headers
  text: string;
  // Total number of pages parsed in the document
  numPages: number;
  // Total count of characters extracted
  charCount: number;
  // Human-friendly title suggested from the filename
  titleSuggestion: string;
  // File size in bytes
  fileSizeBytes: number;
}

/**
 * Extracts digital text from an uploaded PDF File object.
 * Enforces file size limits and validates that the PDF contains selectable text.
 * 
 * @param file - The PDF File uploaded by the user.
 * @returns Promise resolving to ExtractedPdfResult.
 */
export async function extractTextFromPdf(file: File): Promise<ExtractedPdfResult> {
  // Enforce the 50MB file size limit
  const maxSizeBytes = 50 * 1024 * 1024; // 50MB
  if (file.size > maxSizeBytes) {
    throw new Error(
      `File exceeds the 50MB upload limit (File size: ${(file.size / (1024 * 1024)).toFixed(1)}MB). Please choose a smaller document.`
    );
  }

  // Read the binary data from the file as an ArrayBuffer
  const arrayBuffer = await file.arrayBuffer();

  // Load the PDF document using pdfjs-dist
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(arrayBuffer),
    useSystemFonts: true,
  });

  const pdf = await loadingTask.promise;
  const numPages = pdf.numPages;

  // Verify the PDF has pages
  if (numPages === 0) {
    throw new Error('The uploaded PDF appears to have zero pages.');
  }

  const pageTexts: string[] = [];
  let totalChars = 0;

  // Iterate sequentially through each page to extract digital text
  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    const page = await pdf.getPage(pageNum);
    const textContent = await page.getTextContent();

    // Join text chunks while sanitizing multiple spaces
    const pageString = textContent.items
      .map((item: any) => (item && 'str' in item ? item.str : ''))
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (pageString.length > 0) {
      // Append page marker so cards can cite their origin
      pageTexts.push(`[Page ${pageNum}]\n${pageString}`);
      totalChars += pageString.length;
    }
  }

  const combinedText = pageTexts.join('\n\n');

  // If minimal text was found, the PDF is likely scanned image pages without OCR
  if (totalChars < 30) {
    throw new Error(
      'This PDF appears to be a scanned image or contains no selectable digital text. Please paste your notes directly, convert with OCR, or upload a text-searchable document.'
    );
  }

  // Create a clean title suggestion from the file name
  const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
  const titleSuggestion = cleanName
    .split(' ')
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ');

  return {
    text: combinedText,
    numPages,
    charCount: totalChars,
    titleSuggestion,
    fileSizeBytes: file.size,
  };
}
