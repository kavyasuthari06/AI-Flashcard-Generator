/**
 * @file docxExtractor.ts
 * @description Client-side Microsoft Word (.docx) document text extraction utility using Mammoth.
 * Extracts clean plain text from .docx files directly in the browser without sending raw binary files to third-party services.
 */

import mammoth from 'mammoth';

export interface DocxExtractionResult {
  // Extracted plain text content from the DOCX document
  text: string;
  // Suggested title based on the filename
  titleSuggestion: string;
  // Size of the original document in bytes
  fileSizeBytes: number;
}

/**
 * Extracts plain text from an uploaded Microsoft Word (.docx) file.
 * 
 * @param file - The browser File object representing the .docx document.
 * @returns Promise resolving to the extracted text and metadata.
 */
export async function extractTextFromDocx(file: File): Promise<DocxExtractionResult> {
  // Validate that the provided file has a DOCX extension or MIME type
  const isDocx =
    file.name.toLowerCase().endsWith('.docx') ||
    file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';

  if (!isDocx) {
    throw new Error('Unsupported document format. Please upload a Microsoft Word (.docx) file.');
  }

  // Enforce the 50MB file size limit
  const maxSizeBytes = 50 * 1024 * 1024; // 50 Megabytes
  if (file.size > maxSizeBytes) {
    throw new Error(`File exceeds the 50MB limit (File size: ${(file.size / (1024 * 1024)).toFixed(1)}MB). Please upload a smaller document.`);
  }

  try {
    // Read the File as an ArrayBuffer for Mammoth processing
    const arrayBuffer = await file.arrayBuffer();

    // Extract raw text content from the Word document structure
    const result = await mammoth.extractRawText({ arrayBuffer });
    const rawText = (result.value || '').trim();

    // Verify that the document contained readable textual content
    if (!rawText || rawText.length < 10) {
      throw new Error(
        'The Word document appears to be empty or contains only unreadable embedded media/images. Please ensure your document has readable text.'
      );
    }

    // Generate a human-friendly title suggestion by removing the file extension and replacing hyphens/underscores
    const titleSuggestion = file.name
      .replace(/\.docx$/i, '')
      .replace(/[-_]/g, ' ')
      .trim();

    return {
      text: rawText,
      titleSuggestion: titleSuggestion || 'Document Study',
      fileSizeBytes: file.size,
    };
  } catch (error: any) {
    console.error('DOCX text extraction failed:', error);
    throw new Error(
      error.message || 'Failed to extract text from the Word document. The file may be password-protected or corrupted.'
    );
  }
}
