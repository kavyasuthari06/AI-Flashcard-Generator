import React, { useState } from 'react';
import {
  TrendingUp,
  Award,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Flame,
  Calendar,
  Layers,
  Download,
  RotateCcw,
  BookOpen,
  ArrowRight,
} from 'lucide-react';
import { Deck, QuizAttempt, StudyStats } from '../../types';
import { exportAllData, clearAllData } from '../../utils/storage';

interface ProgressViewProps {
  stats: StudyStats;
  decks: Deck[];
  quizHistory: QuizAttempt[];
  onResetData: () => void;
  onNavigate: (tab: any) => void;
}

export const ProgressView: React.FC<ProgressViewProps> = ({
  stats,
  decks,
  quizHistory,
  onResetData,
  onNavigate,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Calculate subject-wise performance
  const subjectPerformance: { [key: string]: { totalAttempts: number; totalScore: number } } = {};
  quizHistory.forEach((q) => {
    const sub = q.subject || 'General';
    if (!subjectPerformance[sub]) {
      subjectPerformance[sub] = { totalAttempts: 0, totalScore: 0 };
    }
    subjectPerformance[sub].totalAttempts++;
    subjectPerformance[sub].totalScore += q.scorePercent;
  });

  const handleExport = () => {
    const jsonStr = exportAllData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recallmate_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3000);
  };

  const handleReset = () => {
    if (
      confirm(
        'Are you sure you want to clear your study data? All created decks and quiz history will be erased.'
      )
    ) {
      clearAllData();
      onResetData();
    }
  };

  const totalCards = stats.totalCards || 1;
  const easyPct = Math.round((stats.easyCount / totalCards) * 100);
  const practicePct = Math.round((stats.practiceCount / totalCards) * 100);
  const unrecalledPct = Math.round((stats.unrecalledCount / totalCards) * 100);
  const unreviewedPct = Math.round((stats.unreviewedCount / totalCards) * 100);


  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>Learning Progress & Analytics</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real metrics calculated from your self-reported Recall Meter ratings and quiz performances.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export JSON Data</span>
          </button>

          <button
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors cursor-pointer"
            title="Clear all stored decks and quiz attempts"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
            <span>Clear Stored Data</span>
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>Application state exported successfully to JSON.</span>
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Total Decks
          </span>
          <div className="text-3xl font-extrabold text-slate-900 mt-1">{stats.totalDecks}</div>
          <p className="text-xs text-slate-500 mt-1">{stats.totalCards} cards across all subjects</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Cards Reviewed
          </span>
          <div className="text-3xl font-extrabold text-emerald-600 mt-1">
            {stats.totalCardsReviewed}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {stats.totalCards > 0
              ? `${Math.round((stats.totalCardsReviewed / stats.totalCards) * 100)}% deck coverage`
              : '0% coverage'}
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Quizzes Completed
          </span>
          <div className="text-3xl font-extrabold text-blue-600 mt-1">
            {stats.quizzesCompleted}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {stats.quizzesCompleted > 0 ? 'Active assessment history' : 'No quiz taken yet'}
          </p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-slate-200/90 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Average Score
          </span>
          <div className="text-3xl font-extrabold text-blue-600 mt-1">
            {stats.quizzesCompleted > 0 ? `${stats.averageQuizScore}%` : '—'}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            {stats.averageQuizScore >= 80 ? 'Mastery territory' : 'Knowledge building'}
          </p>
        </div>
      </div>

      {/* Recall Meter Health Breakdown */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-5 h-5 text-rose-500" />
            <h2 className="text-base font-bold text-slate-900">
              Recall Meter Health Distribution
            </h2>
          </div>
          <span className="text-xs text-slate-500 font-medium">{stats.totalCards} total cards</span>
        </div>

        {/* Visual Stacked Progress Bar */}
        <div className="w-full h-4 rounded-full bg-slate-100 flex overflow-hidden">
          <div
            style={{ width: `${easyPct}%` }}
            className="bg-emerald-500 transition-all"
            title={`${stats.easyCount} Easy / Mastered (${easyPct}%)`}
          />
          <div
            style={{ width: `${practicePct}%` }}
            className="bg-amber-400 transition-all"
            title={`${stats.practiceCount} Need Practice (${practicePct}%)`}
          />
          <div
            style={{ width: `${unrecalledPct}%` }}
            className="bg-rose-500 transition-all"
            title={`${stats.unrecalledCount} Unrecalled (${unrecalledPct}%)`}
          />
          <div
            style={{ width: `${unreviewedPct}%` }}
            className="bg-slate-200 transition-all"
            title={`${stats.unreviewedCount} Unreviewed (${unreviewedPct}%)`}
          />
        </div>

        {/* Category breakdown stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-3 rounded-lg bg-emerald-50/70 border border-emerald-100">
            <div className="text-xs font-semibold text-emerald-800">Mastered (Easy)</div>
            <div className="text-xl font-bold text-emerald-900 mt-0.5">{stats.easyCount}</div>
            <div className="text-[11px] text-emerald-700">{easyPct}% of cards</div>
          </div>

          <div className="p-3 rounded-lg bg-amber-50/70 border border-amber-100">
            <div className="text-xs font-semibold text-amber-800">Needs Practice</div>
            <div className="text-xl font-bold text-amber-900 mt-0.5">{stats.practiceCount}</div>
            <div className="text-[11px] text-amber-700">{practicePct}% of cards</div>
          </div>

          <div className="p-3 rounded-lg bg-rose-50/70 border border-rose-100">
            <div className="text-xs font-semibold text-rose-800">Unrecalled (Priority)</div>
            <div className="text-xl font-bold text-rose-900 mt-0.5">{stats.unrecalledCount}</div>
            <div className="text-[11px] text-rose-700">{unrecalledPct}% of cards</div>
          </div>

          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-xs font-semibold text-slate-700">Unreviewed</div>
            <div className="text-xl font-bold text-slate-900 mt-0.5">{stats.unreviewedCount}</div>
            <div className="text-[11px] text-slate-500">{unreviewedPct}% of cards</div>
          </div>
        </div>
      </div>

      {/* Subject-Wise Performance & Quiz History */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Subject-Wise Mastery */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <h3 className="text-sm font-bold text-slate-900">
            Subject Quiz Performance
          </h3>

          {Object.keys(subjectPerformance).length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              No subject quiz data recorded yet. Take a quiz to populate performance by topic.
            </div>
          ) : (
            <div className="space-y-3">
              {Object.entries(subjectPerformance).map(([subject, data]) => {
                const avg = Math.round(data.totalScore / data.totalAttempts);
                return (
                  <div key={subject} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-800">{subject}</span>
                      <span className="font-bold text-slate-900">{avg}% ({data.totalAttempts} quizzes)</span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div
                        className={`h-full ${
                          avg >= 80 ? 'bg-emerald-500' : avg >= 60 ? 'bg-blue-600' : 'bg-amber-500'
                        }`}
                        style={{ width: `${avg}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Recent Quiz Attempts Log */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Recent Quiz History</h3>
            <span className="text-xs text-slate-400">{quizHistory.length} attempts total</span>
          </div>

          {quizHistory.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
              <HelpCircle className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-700">No quiz attempts yet</p>
              <p className="text-[11px] text-slate-400 mt-0.5 mb-3">
                Select a deck from Quiz Mode to test your retention.
              </p>
              <button
                onClick={() => onNavigate('quiz')}
                className="px-3.5 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 border border-blue-600 shadow-xs cursor-pointer"
              >
                Launch Quiz
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 text-[11px]">
                    <th className="pb-2 font-medium">Date</th>
                    <th className="pb-2 font-medium">Deck Title</th>
                    <th className="pb-2 font-medium">Difficulty</th>
                    <th className="pb-2 font-medium">Questions</th>
                    <th className="pb-2 font-medium text-right">Score</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {quizHistory.slice(0, 8).map((attempt) => (
                    <tr key={attempt.id} className="hover:bg-slate-50/60">
                      <td className="py-2.5 text-slate-500">
                        {new Date(attempt.timestamp).toLocaleDateString([], {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </td>
                      <td className="py-2.5 font-semibold text-slate-800 truncate max-w-[180px]">
                        {attempt.deckTitle}
                      </td>
                      <td className="py-2.5 text-slate-500">{attempt.difficulty}</td>
                      <td className="py-2.5 text-slate-500">
                        {attempt.correctAnswers}/{attempt.totalQuestions}
                      </td>
                      <td className="py-2.5 text-right font-bold">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] ${
                            attempt.scorePercent >= 80
                              ? 'bg-emerald-100 text-emerald-800'
                              : attempt.scorePercent >= 60
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {attempt.scorePercent}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
