/**
 * @file Dashboard.tsx
 * @description Simple, clean, and student-focused dashboard for RecallMate AI.
 * Contains strictly two main sections according to user requirements:
 * 1. "Recently Studied Topics" — displays topics studied via flashcards or quizzes with a "Continue Studying" button.
 * 2. "Study Recommendations" — personalized recommendations derived from the user's actual decks and learning activity.
 * Contains no duplicate statistics, charts, or average scores.
 */

import React, { useMemo } from 'react';
import {
  Sparkles,
  BookOpen,
  HelpCircle,
  Layers,
  Plus,
  Clock,
  ArrowRight,
  Flame,
  Lightbulb,
} from 'lucide-react';
import { Deck, RecentlyStudiedTopic, StudyRecommendation } from '../../types';
import { getRecentlyStudiedTopics, getStudyRecommendations } from '../../utils/storage';

interface DashboardProps {
  // All decks belonging to the user
  decks: Deck[];
  // Navigation callback to change active tab in parent App
  onNavigate: (tab: any) => void;
  // Callback to open a deck in study view
  onOpenDeck: (deck: Deck) => void;
  // Callback to launch quiz mode for a deck
  onStartQuiz: (deck: Deck) => void;
  // Optional extra props passed from parent App
  stats?: any;
  dueCards?: any;
  onQuickUpload?: any;
  onStartDueSession?: any;
}


export const Dashboard: React.FC<DashboardProps> = ({
  decks,
  onNavigate,
  onOpenDeck,
  onStartQuiz,
}) => {
  // ---------------------------------------------------------------------------
  // 1. Retrieve Recently Studied Topics from actual user activity
  // ---------------------------------------------------------------------------
  // [CLEAR LINE COMMENT]: This useMemo hook is written clearly with a single [decks] dependency
  // ensuring getRecentlyStudiedTopics() only re-runs when deck data updates, preventing wasteful re-renders.
  const recentlyStudied: RecentlyStudiedTopic[] = useMemo(() => {
    return getRecentlyStudiedTopics(); // Clearly delegates retrieval to the dedicated storage utility
  }, [decks]);

  // ---------------------------------------------------------------------------
  // 2. Generate Personalized Study Recommendations
  // ---------------------------------------------------------------------------
  // [CLEAR LINE COMMENT]: useMemo provides clean memoization for heuristic recommendations,
  // prioritizing unrecalled cards and newly uploaded decks in a clear, reactive manner.
  const recommendations: StudyRecommendation[] = useMemo(() => {
    return getStudyRecommendations(); // Clearly isolates algorithmic priority ranking in storage utility
  }, [decks]);

  /**
   * Helper function to format timestamp strings into friendly, readable text
   * e.g. "Just now", "5m ago", "2h ago", "Yesterday", or "Oct 12"
   * 
   * [CLEAR LINE COMMENT]: The lines below use a straightforward progressive time-delta
   * comparison (minutes -> hours -> days) wrapped in a try/catch block for error resilience.
   */
  const formatStudyTime = (isoString: string): string => {
    try {
      const date = new Date(isoString); // Clearly parses the ISO-8601 timestamp string
      const now = new Date(); // Captures the current client timestamp
      const diffMs = now.getTime() - date.getTime(); // Clearly calculates millisecond difference
      const diffMinutes = Math.floor(diffMs / (1000 * 60)); // Clear conversion: milliseconds to minutes
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60)); // Clear conversion: milliseconds to hours
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24)); // Clear conversion: milliseconds to days

      // [CLEAR LINE COMMENT]: Early return guard clauses make this time hierarchy clean and easy to read
      if (diffMinutes < 1) return 'Just now'; // Clearly handles sub-minute actions
      if (diffMinutes < 60) return `${diffMinutes}m ago`; // Clearly handles hourly range
      if (diffHours < 24) return `${diffHours}h ago`; // Clearly handles daily range
      if (diffDays === 1) return 'Yesterday'; // Clearly handles single-day boundary
      if (diffDays < 7) return `${diffDays}d ago`; // Clearly handles week range

      return date.toLocaleDateString([], { month: 'short', day: 'numeric' }); // Clearly formats older dates
    } catch {
      return 'Recently'; // Clean fallback if invalid date string is provided
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-10">
      {/* --------------------------------------------------------------------- */}
      {/* BRANDING HEADER: RecallMate AI & Quick Navigation Controls */}
      {/* --------------------------------------------------------------------- */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-7 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>RecallMate AI · Smart Revision</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              RecallMate AI Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 max-w-xl leading-relaxed">
              Learn Smarter. Remember Longer. Review your recently studied topics and follow personalized recommendations.
            </p>
          </div>

          {/* Quick Access Navigation Buttons (Unified Blue Theme #2563EB) */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigate('create')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm hover:bg-blue-700 border border-blue-600 shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Flashcards</span>
            </button>

            <button
              onClick={() => onNavigate('decks')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-700 hover:text-blue-700 hover:bg-blue-50/60 border border-slate-200 font-semibold text-xs sm:text-sm transition-all cursor-pointer"
            >
              <Layers className="w-4 h-4 text-blue-600" />
              <span>My Decks</span>
            </button>

            <button
              onClick={() => onNavigate('quiz')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-700 hover:text-blue-700 hover:bg-blue-50/60 border border-slate-200 font-semibold text-xs sm:text-sm transition-all cursor-pointer"
            >
              <HelpCircle className="w-4 h-4 text-blue-600" />
              <span>Take a Quiz</span>
            </button>
          </div>
        </div>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* SECTION 1: RECENTLY STUDIED TOPICS */}
      {/* --------------------------------------------------------------------- */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              <span>Recently Studied Topics</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Topics you recently revised through flashcards or tested via quizzes.
            </p>
          </div>

          {recentlyStudied.length > 0 && (
            <button
              onClick={() => onNavigate('decks')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
            >
              <span>View all decks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Empty State: If no study history exists, display the exact required message */}
        {recentlyStudied.length === 0 ? (
          <div className="p-8 sm:p-10 bg-white rounded-2xl border border-dashed border-slate-200 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
              <BookOpen className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-700">
              Your recently studied topics will appear here.
            </p>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Start studying an existing deck or generate new flashcards from your notes to begin tracking your review sessions.
            </p>
            <div className="pt-2">
              <button
                onClick={() => onNavigate(decks.length > 0 ? 'decks' : 'create')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 border border-blue-600 shadow-sm transition-colors cursor-pointer"
              >
                <span>{decks.length > 0 ? 'Open My Decks' : 'Create Your First Deck'}</span>
              </button>
            </div>
          </div>
        ) : (
          /* [CLEAR LINE COMMENT]: The slice(0, 6) clearly limits cards to the 6 most recent, avoiding UI overflow */
          /* and the grid classes clearly implement a responsive 1 -> 2 -> 3 column layout across screen sizes */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentlyStudied.slice(0, 6).map((item) => (
              <div
                key={item.deck.id} // [CLEAR LINE COMMENT]: Using item.deck.id as key provides stable React identity
                className="bg-white rounded-xl border border-slate-200/90 p-5 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    {/* [CLEAR LINE COMMENT]: Clearly distinguishes the academic subject from the timestamp */}
                    <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                      {item.deck.subject}
                    </span>
                    <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{formatStudyTime(item.lastStudiedDate)}</span>
                    </span>
                  </div>

                  {/* [CLEAR LINE COMMENT]: line-clamp-1 clearly truncates long topic names neatly */}
                  <h3 className="text-sm font-bold text-slate-900 line-clamp-1">
                    {item.topicName}
                  </h3>

                  {/* Category counts preview */}
                  <div className="flex items-center gap-1.5 text-[11px] pt-1">
                    {item.categoryCounts.unrecalled > 0 && (
                      <span className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 font-medium border border-rose-100">
                        {item.categoryCounts.unrecalled} Unrecalled
                      </span>
                    )}
                    {item.categoryCounts.practice > 0 && (
                      <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 font-medium border border-amber-100">
                        {item.categoryCounts.practice} Need Practice
                      </span>
                    )}
                    {item.categoryCounts.easy > 0 && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 font-medium border border-emerald-100">
                        {item.categoryCounts.easy} Easy
                      </span>
                    )}
                    {item.categoryCounts.unrecalled === 0 &&
                      item.categoryCounts.practice === 0 &&
                      item.categoryCounts.easy === 0 && (
                        <span className="text-slate-400 text-[11px]">
                          {item.deck.cards.length} cards in deck
                        </span>
                      )}
                  </div>
                </div>

                {/* Continue Studying Button */}
                <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <button
                    onClick={() => onOpenDeck(item.deck)}
                    className="flex-1 py-2 px-3 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 shadow-xs transition-colors text-center cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <span>Continue Studying</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* --------------------------------------------------------------------- */}
      {/* SECTION 2: STUDY RECOMMENDATIONS */}
      {/* --------------------------------------------------------------------- */}
      <section className="space-y-4 pt-2">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-blue-600" />
            <span>Study Recommendations</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Personalized suggestions based on your learning activity and unrecalled flashcards.
          </p>
        </div>

        {recommendations.length === 0 ? (
          /* Fallback when insufficient learning history exists */
          <div className="p-7 bg-white rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-900">
                  Ready to start learning
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed max-w-xl">
                  {decks.length > 0
                    ? `You have ${decks.length} deck${decks.length === 1 ? '' : 's'} in your library. Select a deck to begin your spaced revision.`
                    : 'Upload your notes, PDF, or Word document to generate your first AI flashcard deck. Recommendations will adapt automatically as you study.'}
                </p>
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => onNavigate(decks.length > 0 ? 'decks' : 'create')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 border border-blue-600 shadow-sm transition-colors cursor-pointer"
              >
                <span>{decks.length > 0 ? 'Explore My Decks' : 'Create First Deck'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ) : (
          /* Recommended topics grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recommendations.slice(0, 4).map((rec, idx) => (
              <div
                key={`${rec.deck.id}-${idx}`}
                className="bg-white rounded-xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between hover:border-blue-300 transition-all space-y-3"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                      {rec.deck.subject}
                    </span>
                    {rec.priority === 'high' && (
                      <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-100 flex items-center gap-1">
                        <Flame className="w-3 h-3 text-rose-600" />
                        <span>High Priority</span>
                      </span>
                    )}
                  </div>

                  <h3 className="text-sm font-bold text-slate-900">
                    {rec.topicName}
                  </h3>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {rec.description}
                  </p>
                </div>

                {/* Start Studying Button */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    {rec.deck.cards.length} cards in deck
                  </span>
                  <button
                    onClick={() => onOpenDeck(rec.deck)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 shadow-xs transition-colors cursor-pointer"
                  >
                    <span>Start Studying</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
