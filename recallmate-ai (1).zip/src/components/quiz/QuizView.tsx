/**
 * @file QuizView.tsx
 * @description Interactive quiz arena component for RecallMate AI.
 * Synthesizes 4-option multiple-choice questions grounded in deck flashcards using Gemini AI.
 * 
 * Features:
 * - Deck, question count, and difficulty selection screens
 * - Instant answer feedback with explanations for correct and distractor options
 * - Consistent #2563EB blue selection theme for answers and control buttons
 * - Detailed post-quiz score breakdown, missed questions review, and retry flow
 * - Automatic persistence of quiz attempts to local storage
 */

import React, { useState } from 'react';
import {
  HelpCircle,
  CheckCircle2,
  XCircle,
  ArrowRight,
  RotateCcw,
  BookOpen,
  Award,
  Loader2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { Deck, DifficultyLevel, QuizAttempt, QuizQuestion, QuizUserAnswer } from '../../types';
import { requestQuizGeneration } from '../../utils/api';

interface QuizViewProps {
  // All user decks available to be quizzed
  decks: Deck[];
  // Optionally preselected deck if opened from a deck card
  selectedDeck?: Deck | null;
  // Callback when a quiz attempt is finished and saved
  onSaveQuizAttempt: (attempt: QuizAttempt) => void;
  // Callback to return to flashcard study mode
  onStudyDeck: (deck: Deck) => void;
  // Callback to return to the dashboard
  onBackToDashboard: () => void;
}

export const QuizView: React.FC<QuizViewProps> = ({
  decks,
  selectedDeck: initialDeck = null,
  onSaveQuizAttempt,
  onStudyDeck,
  onBackToDashboard,
}) => {
  // ---------------------------------------------------------------------------
  // SETUP STAGE STATE
  // ---------------------------------------------------------------------------

  // The deck currently selected for testing
  const [currentDeck, setCurrentDeck] = useState<Deck | null>(
    initialDeck || (decks.length > 0 ? decks[0] : null)
  );

  // Number of multiple-choice questions to generate (5, 10, or 15)
  const [questionCount, setQuestionCount] = useState<number>(5);

  // Target difficulty level
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('Intermediate');

  // Loading indicator while Gemini generates questions
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Error message if quiz generation fails
  const [generationError, setGenerationError] = useState<string | null>(null);

  // ---------------------------------------------------------------------------
  // ACTIVE QUIZ INTERACTION STATE
  // ---------------------------------------------------------------------------

  // List of generated multiple-choice questions
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);

  // Zero-based index of the question currently being answered
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Zero-based index of the option chosen by the user for the current question
  const [selectedOption, setSelectedOption] = useState<number | null>(null);

  // Flag indicating if the user has locked in and submitted their choice
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);

  // Historical log of user answers for each question
  const [userAnswers, setUserAnswers] = useState<QuizUserAnswer[]>([]);

  // Flag indicating whether the quiz is completed
  const [isQuizCompleted, setIsQuizCompleted] = useState<boolean>(false);

  /**
   * Generates quiz questions using the server-side Gemini AI endpoint.
   * Falls back to offline question generation if network or rate limit errors occur.
   */
  const handleStartQuiz = async () => {
    if (!currentDeck) return;
    setIsGenerating(true);
    setGenerationError(null);

    try {
      const availableCards = currentDeck.cards.length;
      const count = Math.min(questionCount, Math.max(availableCards, 3));

      const generatedQuestions = await requestQuizGeneration({
        deckTitle: currentDeck.title,
        subject: currentDeck.subject,
        cards: currentDeck.cards,
        sourceNotes: currentDeck.sourceText,
        questionCount: count,
        difficulty,
      });

      if (!generatedQuestions || generatedQuestions.length === 0) {
        throw new Error('Unable to construct questions from this deck.');
      }

      setQuestions(generatedQuestions);
      setCurrentIndex(0);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
      setUserAnswers([]);
      setIsQuizCompleted(false);
    } catch (err: any) {
      console.error('Quiz generation error:', err);
      if (currentDeck.cards.length >= 3) {
        // Fallback local quiz generation to ensure students can always practice
        const fallbackQs = generateFallbackQuestions(currentDeck, questionCount);
        setQuestions(fallbackQs);
        setCurrentIndex(0);
        setSelectedOption(null);
        setIsAnswerSubmitted(false);
        setUserAnswers([]);
        setIsQuizCompleted(false);
      } else {
        setGenerationError(
          err?.message || 'Could not generate quiz. Please ensure the deck has at least 3 cards.'
        );
      }
    } finally {
      setIsGenerating(false);
    }
  };

  /**
   * Evaluates the selected answer and records it
   */
  const handleSubmitAnswer = () => {
    if (selectedOption === null || isAnswerSubmitted) return;

    const currentQ = questions[currentIndex];
    const isCorrect = selectedOption === currentQ.correctAnswerIndex;

    const answerRecord: QuizUserAnswer = {
      questionId: currentQ.id,
      questionText: currentQ.question,
      selectedOptionIndex: selectedOption,
      correctOptionIndex: currentQ.correctAnswerIndex,
      isCorrect,
      explanation: currentQ.explanation,
    };

    setUserAnswers((prev) => [...prev, answerRecord]);
    setIsAnswerSubmitted(true);
  };

  /**
   * Moves to next question or finalizes the quiz if at the last question
   */
  const handleNextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerSubmitted(false);
    } else {
      finishQuiz();
    }
  };

  /**
   * Finalizes quiz session, computes score percentage, and saves attempt
   */
  const finishQuiz = () => {
    setIsQuizCompleted(true);
    if (!currentDeck) return;

    const total = questions.length;
    const finalCorrect = userAnswers.filter((a) => a.isCorrect).length;
    const scorePercent = Math.round((finalCorrect / total) * 100);

    const attempt: QuizAttempt = {
      id: `attempt-${Date.now()}`,
      deckId: currentDeck.id,
      deckTitle: currentDeck.title,
      subject: currentDeck.subject,
      timestamp: new Date().toISOString(),
      totalQuestions: total,
      correctAnswers: finalCorrect,
      scorePercent,
      difficulty,
      answers: userAnswers,
    };

    onSaveQuizAttempt(attempt);
  };

  /**
   * Retries only missed questions
   */
  const handleRetryMissed = () => {
    const missedAnswers = userAnswers.filter((a) => !a.isCorrect);
    const missedQuestions = questions.filter((q) =>
      missedAnswers.some((a) => a.questionId === q.id)
    );

    if (missedQuestions.length === 0) return;

    setQuestions(missedQuestions);
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswerSubmitted(false);
    setUserAnswers([]);
    setIsQuizCompleted(false);
  };

  // Score statistics calculations
  const currentQ = questions[currentIndex];
  const totalCorrect = userAnswers.filter((a) => a.isCorrect).length;
  const missedCount = userAnswers.filter((a) => !a.isCorrect).length;
  const scorePercent = questions.length > 0 ? Math.round((totalCorrect / questions.length) * 100) : 0;

  const difficultyLevels: { level: DifficultyLevel; label: string }[] = [
    { level: 'Beginner', label: 'Easy' },
    { level: 'Intermediate', label: 'Medium' },
    { level: 'Advanced', label: 'Hard' },
  ];

  // ---------------------------------------------------------------------------
  // 1. SETUP CONFIGURATION SCREEN
  // ---------------------------------------------------------------------------
  if (questions.length === 0 && !isQuizCompleted) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 pb-10">
        <div className="pb-4 border-b border-slate-200">
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-blue-600" />
            <span>Interactive Quiz Arena</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Test your knowledge with multiple-choice questions synthesized directly from your study deck.
          </p>
        </div>

        {generationError && (
          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
            <span>{generationError}</span>
          </div>
        )}

        <div className="bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/90 shadow-xs space-y-6">
          {/* Deck Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Select Deck
            </label>
            {decks.length === 0 ? (
              <div className="text-xs text-rose-600 p-3.5 rounded-xl bg-rose-50 border border-rose-200">
                No saved decks found. Please create a flashcard deck first.
              </div>
            ) : (
              <select
                value={currentDeck?.id || ''}
                onChange={(e) => {
                  const found = decks.find((d) => d.id === e.target.value);
                  if (found) setCurrentDeck(found);
                }}
                className="w-full text-xs sm:text-sm font-medium p-3 rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
              >
                {decks.map((deck) => (
                  <option key={deck.id} value={deck.id}>
                    {deck.title} ({deck.subject} · {deck.cards.length} cards)
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Question Count Selector (Consistent Blue Selection) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Question Count
            </label>
            <div className="grid grid-cols-3 gap-2.5 max-w-sm">
              {[5, 10, 15].map((cnt) => (
                <button
                  key={cnt}
                  type="button"
                  onClick={() => setQuestionCount(cnt)}
                  className={`py-2.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    questionCount === cnt
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                  }`}
                >
                  {cnt} Questions
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty Level (Consistent Blue Selection) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
              Difficulty Level
            </label>
            <div className="grid grid-cols-3 gap-2.5 max-w-sm">
              {difficultyLevels.map(({ level, label }) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setDifficulty(level)}
                  className={`py-2.5 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                    difficulty === level
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Start Quiz Action */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={onBackToDashboard}
              className="text-xs font-semibold text-slate-600 hover:text-blue-700 transition-colors"
            >
              Back to Dashboard
            </button>

            <button
              onClick={handleStartQuiz}
              disabled={!currentDeck || isGenerating}
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm hover:bg-blue-700 border border-blue-600 disabled:opacity-50 transition-all cursor-pointer shadow-sm shadow-blue-600/20"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Quiz Questions...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Start Quiz</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // 2. QUIZ COMPLETION SUMMARY SCREEN (Displays Score on Quiz Page)
  // ---------------------------------------------------------------------------
  if (isQuizCompleted) {
    const missedAnswers = userAnswers.filter((a) => !a.isCorrect);

    return (
      <div className="max-w-3xl mx-auto space-y-6 pb-12 animate-fade-in">
        {/* Results Header Card */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-8 shadow-xs text-center space-y-4">
          <div className="w-16 h-16 rounded-full mx-auto flex items-center justify-center bg-blue-50 text-blue-600 shadow-inner">
            <Award className="w-8 h-8" />
          </div>

          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
              Quiz Completed
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
              {currentDeck?.title}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">{currentDeck?.subject} · {difficulty} level</p>
          </div>

          {/* Score percentage */}
          <div className="py-2">
            <div className="text-5xl font-black text-slate-900">
              {scorePercent}%
            </div>
            <p className="text-xs font-semibold text-slate-600 mt-1">
              {totalCorrect} correct of {questions.length} total questions
            </p>
          </div>

          {/* Performance Badge */}
          <div className="inline-block px-4 py-1.5 rounded-full text-xs font-bold tracking-wide">
            {scorePercent >= 80 ? (
              <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full">
                Great job! Solid retention.
              </span>
            ) : scorePercent >= 60 ? (
              <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
                Good effort! Review missed questions below.
              </span>
            ) : (
              <span className="bg-rose-100 text-rose-800 px-3 py-1 rounded-full">
                Needs revision. Study your flashcards to reinforce concepts.
              </span>
            )}
          </div>

          {/* Action Buttons */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
            {missedCount > 0 && (
              <button
                onClick={handleRetryMissed}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm hover:bg-blue-700 border border-blue-600 shadow-xs transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Retry Missed Questions ({missedCount})</span>
              </button>
            )}

            {currentDeck && (
              <button
                onClick={() => onStudyDeck(currentDeck)}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-slate-700 hover:text-blue-700 hover:bg-blue-50/60 border border-slate-200 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-blue-600" />
                <span>Study Flashcards</span>
              </button>
            )}

            <button
              onClick={onBackToDashboard}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-600 hover:bg-slate-100 border border-slate-200 text-xs font-semibold transition-colors cursor-pointer"
            >
              Dashboard
            </button>
          </div>
        </div>

        {/* Detailed Review of Missed / All Answers */}
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">
              Question-by-Question Review
            </h3>
            <span className="text-xs text-slate-500">
              {missedAnswers.length} incorrect · {totalCorrect} correct
            </span>
          </div>

          <div className="space-y-4">
            {userAnswers.map((ans, idx) => (
              <div
                key={ans.questionId}
                className={`p-4 rounded-xl border transition-all ${
                  ans.isCorrect
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : 'border-rose-200 bg-rose-50/20'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    {ans.isCorrect ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                    )}
                    <span className="text-xs font-bold text-slate-900">
                      Q{idx + 1}. {ans.questionText}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ans.isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {ans.isCorrect ? 'Correct' : 'Missed'}
                  </span>
                </div>

                {!ans.isCorrect && (
                  <div className="text-xs space-y-1 pl-6">
                    <p className="text-rose-700">
                      <span className="font-semibold">Your answer: </span>
                      Option {String.fromCharCode(65 + ans.selectedOptionIndex)}
                    </p>
                    <p className="text-emerald-700">
                      <span className="font-semibold">Correct answer: </span>
                      Option {String.fromCharCode(65 + ans.correctOptionIndex)}
                    </p>
                  </div>
                )}

                <div className="mt-2.5 pt-2 border-t border-slate-200/60 pl-6 text-xs text-slate-600 leading-relaxed">
                  <span className="font-semibold text-slate-800">Explanation: </span>
                  {ans.explanation}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // 3. ACTIVE QUESTION ANSWERING SCREEN
  // ---------------------------------------------------------------------------
  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-12">
      {/* Top Quiz Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-200">
        <div>
          <span className="text-xs text-blue-700 font-semibold">{currentDeck?.title}</span>
          <h2 className="text-base font-bold text-slate-900">
            Question {currentIndex + 1} of {questions.length}
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700">
            Score: {totalCorrect} / {currentIndex + (isAnswerSubmitted ? 1 : 0)}
          </div>
        </div>
      </div>

      {/* Progress Bar (Consistent Blue #2563EB) */}
      <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
        <div
          className="h-full bg-blue-600 transition-all duration-300"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="space-y-2">
          {currentQ.sourceReference && (
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              Topic: {currentQ.sourceReference}
            </span>
          )}
          <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
            {currentQ.question}
          </h3>
        </div>

        {/* Options List (Consistent Blue Selection Theme: #2563EB) */}
        <div className="space-y-2.5">
          {currentQ.options.map((optionText, optIndex) => {
            // [CLEAR LINE COMMENT]: String.fromCharCode(65 + optIndex) clearly generates clean letter badges 'A', 'B', 'C', 'D'
            const letter = String.fromCharCode(65 + optIndex);
            // [CLEAR LINE COMMENT]: Simple equality clearly checks if current option is the user's active choice
            const isSelected = selectedOption === optIndex;
            // [CLEAR LINE COMMENT]: Directly validates option index against the question's verified correct answer index
            const isCorrectOption = optIndex === currentQ.correctAnswerIndex;

            // [CLEAR LINE COMMENT]: Default neutral state clearly uses accessible contrast with slate border and text
            let buttonStyle = 'border-slate-200 bg-white text-slate-800 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-900';
            let badgeStyle = 'bg-slate-100 text-slate-600 border border-slate-200';
            let textStyle = 'text-slate-800';

            // [CLEAR LINE COMMENT]: Clear conditional branching controls immediate feedback after answer submission
            if (isAnswerSubmitted) {
              if (isCorrectOption) {
                // Clearly highlights verified correct option with emerald green
                buttonStyle = 'border-emerald-500 bg-emerald-50/90 text-emerald-950 ring-1 ring-emerald-500 font-medium';
                badgeStyle = 'bg-emerald-600 text-white';
                textStyle = 'text-emerald-950 font-semibold';
              } else if (isSelected && !isCorrectOption) {
                // Clearly highlights user's incorrect choice with rose red
                buttonStyle = 'border-rose-500 bg-rose-50/90 text-rose-950 ring-1 ring-rose-500 font-medium';
                badgeStyle = 'bg-rose-600 text-white';
                textStyle = 'text-rose-950 font-semibold';
              } else {
                // Clearly dims unselected distractors to focus the learner on key answers
                buttonStyle = 'border-slate-200 opacity-60 bg-slate-50 text-slate-500';
                badgeStyle = 'bg-slate-100 text-slate-400 border border-slate-200';
                textStyle = 'text-slate-500';
              }
            } else if (isSelected) {
              // [CLEAR LINE COMMENT]: Active selection state clearly implements the #2563EB primary blue theme
              buttonStyle = 'border-blue-600 bg-blue-600 text-white ring-2 ring-blue-600/30 font-semibold shadow-sm';
              badgeStyle = 'bg-white text-blue-600 font-bold border border-blue-600';
              textStyle = 'text-white font-medium';
            }

            return (
              <button
                key={optIndex}
                type="button"
                disabled={isAnswerSubmitted} // [CLEAR LINE COMMENT]: Clearly locks selections once submitted
                onClick={() => setSelectedOption(optIndex)}
                className={`w-full p-3.5 sm:p-4 rounded-xl border text-left flex items-start gap-3 transition-all cursor-pointer ${buttonStyle}`}
              >
                <div
                  className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5 ${badgeStyle}`}
                >
                  {letter}
                </div>
                <span className={`text-xs sm:text-sm leading-relaxed flex-1 ${textStyle}`}>
                  {optionText}
                </span>

                {isAnswerSubmitted && isCorrectOption && (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                )}
                {isAnswerSubmitted && isSelected && !isCorrectOption && (
                  <XCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        {/* Immediate Feedback Card upon submit */}
        {isAnswerSubmitted && (
          <div
            className={`p-4 rounded-xl border text-xs leading-relaxed animate-fade-in ${
              selectedOption === currentQ.correctAnswerIndex
                ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900'
                : 'bg-rose-50/60 border-rose-200 text-rose-900'
            }`}
          >
            <div className="font-bold flex items-center gap-1.5 mb-1">
              {selectedOption === currentQ.correctAnswerIndex ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Correct Answer!</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-rose-600" />
                  <span>Incorrect. Option {String.fromCharCode(65 + currentQ.correctAnswerIndex)} is the right answer.</span>
                </>
              )}
            </div>
            <p className="mt-1 opacity-90">{currentQ.explanation}</p>
          </div>
        )}

        {/* Submission & Next Buttons */}
        <div className="pt-2 flex items-center justify-between">
          <div className="text-xs text-slate-400">
            {!isAnswerSubmitted ? 'Select an answer to submit' : 'Review explanation above'}
          </div>

          {!isAnswerSubmitted ? (
            <button
              onClick={handleSubmitAnswer}
              disabled={selectedOption === null}
              className="px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700 border border-blue-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all cursor-pointer shadow-xs"
            >
              Submit Answer
            </button>
          ) : (
            <button
              onClick={handleNextQuestion}
              className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700 border border-blue-600 transition-all cursor-pointer shadow-xs"
            >
              <span>{currentIndex < questions.length - 1 ? 'Next Question' : 'View Results'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * Fallback quiz generator that creates questions directly from deck flashcard data
 * in the event of temporary network issues or API outages.
 */
function generateFallbackQuestions(deck: Deck, count: number): QuizQuestion[] {
  const cards = deck.cards;
  const questionsToMake = Math.min(count, cards.length);
  const result: QuizQuestion[] = [];

  for (let i = 0; i < questionsToMake; i++) {
    const targetCard = cards[i];
    const otherAnswers = cards
      .filter((_, idx) => idx !== i)
      .map((c) => c.answer)
      .slice(0, 3);

    while (otherAnswers.length < 3) {
      otherAnswers.push(`Alternative concept in ${deck.subject}`);
    }

    const options = [targetCard.answer, ...otherAnswers].sort(() => Math.random() - 0.5);
    const correctIndex = options.indexOf(targetCard.answer);

    result.push({
      id: `local-q-${i}`,
      question: targetCard.question,
      options,
      correctAnswerIndex: correctIndex,
      explanation: targetCard.explanation || `Derived from ${targetCard.topic}`,
      sourceReference: targetCard.topic,
    });
  }

  return result;
}
