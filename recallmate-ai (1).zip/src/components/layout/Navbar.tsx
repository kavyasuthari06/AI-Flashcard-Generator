import React from 'react';
import { Menu, X, Brain, Sparkles, PlusCircle } from 'lucide-react';
import { ActiveTab } from './Sidebar';
import { StudyStats } from '../../types';

interface NavbarProps {
  activeTab: ActiveTab;
  onNavigate: (tab: ActiveTab) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (open: boolean) => void;
  stats: StudyStats;
  onStartDueRevision?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onNavigate,
  isMobileMenuOpen,
  setIsMobileMenuOpen,
  stats,
  onStartDueRevision,
}) => {
  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Study Dashboard';
      case 'create':
        return 'Create Flashcards';
      case 'decks':
        return 'My Decks Library';
      case 'study':
        return 'Interactive Study Mode';
      case 'quiz':
        return 'Quiz Mode';
      case 'progress':
        return 'Learning Progress & Analytics';
      default:
        return 'RecallMate AI';
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200/80 sticky top-0 z-30 flex items-center justify-between px-4 sm:px-8">
      {/* Left: Mobile hamburger & breadcrumb */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors"
          aria-label="Toggle Navigation Menu"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        <div className="hidden md:flex items-center gap-2 text-sm text-slate-500">
          <span>RecallMate</span>
          <span className="text-slate-300">/</span>
          <span className="font-semibold text-slate-900">{getTabTitle()}</span>
        </div>

        <div className="md:hidden flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-600 flex items-center justify-center text-white">
            <Brain className="w-4 h-4" />
          </div>
          <span className="font-bold text-slate-900 text-sm">RecallMate AI</span>
        </div>
      </div>

      {/* Right: Quick Actions */}
      <div className="flex items-center gap-2.5">
        {stats.cardsDueToday > 0 && onStartDueRevision && (
          <button
            onClick={onStartDueRevision}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition-colors cursor-pointer"
          >
            <span>Revise Due Today</span>
            <span className="px-1.5 py-0.2 rounded-full bg-rose-200 text-rose-800 text-[10px]">
              {stats.cardsDueToday}
            </span>
          </button>
        )}

        <button
          onClick={() => onNavigate('create')}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium bg-blue-600 text-white hover:bg-blue-700 shadow-sm transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>New Deck</span>
        </button>
      </div>
    </header>
  );
};
