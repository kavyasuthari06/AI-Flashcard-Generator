/**
 * @file Sidebar.tsx
 * @description Persistent desktop sidebar navigation for RecallMate AI.
 * Displays brand identity, main navigation tabs, dynamic counters, and spaced revision status.
 */

import React from 'react';
import {
  LayoutDashboard,
  Sparkles,
  HelpCircle,
  TrendingUp,
  Brain,
  Layers,
  Flame,
} from 'lucide-react';
import { StudyStats } from '../../types';

// Tab identifiers for application routing
export type ActiveTab = 'dashboard' | 'create' | 'decks' | 'study' | 'quiz' | 'progress';

interface SidebarProps {
  // Current active navigation tab
  activeTab: ActiveTab;
  // Handler to switch the active navigation tab
  onNavigate: (tab: ActiveTab) => void;
  // Global study metrics
  stats: StudyStats;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onNavigate, stats }) => {
  // Navigation items definition
  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'create' as ActiveTab,
      label: 'Create Flashcards',
      icon: Sparkles,
      highlight: true,
    },
    {
      id: 'decks' as ActiveTab,
      label: 'My Decks',
      icon: Layers,
      count: stats.totalDecks,
    },
    {
      id: 'quiz' as ActiveTab,
      label: 'Quiz Mode',
      icon: HelpCircle,
    },
    {
      id: 'progress' as ActiveTab,
      label: 'Progress',
      icon: TrendingUp,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-100 flex-shrink-0 flex flex-col border-r border-slate-800 select-none min-h-screen">
      {/* --------------------------------------------------------------------- */}
      {/* BRANDING HEADER: RecallMate AI */}
      {/* --------------------------------------------------------------------- */}
      <div className="p-5 border-b border-slate-800/80">
        <button
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-3 text-left w-full group cursor-pointer focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-600/30 group-hover:bg-blue-500 transition-colors">
            <Brain className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-lg tracking-tight text-white">RecallMate</span>
              <span className="text-xs font-semibold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">AI</span>
            </div>
            <p className="text-xs text-slate-400 font-medium">Learn Smarter. Remember Longer.</p>
          </div>
        </button>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* NAVIGATION ITEMS (Active Blue Theme: #2563EB) */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex-1 px-3 py-5 space-y-1.5 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider uppercase text-slate-400">
          Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer text-left ${
                isActive
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/40'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 ${
                    isActive ? 'text-white' : item.highlight ? 'text-blue-400' : 'text-slate-400'
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {item.count !== undefined && (
                <span className="text-xs text-slate-400 font-medium">
                  {item.count}
                </span>
              )}
            </button>
          );
        })}

        {/* ------------------------------------------------------------------- */}
        {/* RECALL METER INFO CARD */}
        {/* ------------------------------------------------------------------- */}
        <div className="mt-8 p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs">
          <div className="flex items-center gap-2 text-blue-300 font-semibold mb-1">
            <Flame className="w-3.5 h-3.5 text-blue-400" />
            <span>Recall Categories</span>
          </div>
          <p className="text-slate-400 leading-relaxed text-[11px]">
            Unrecalled and Need Practice cards are prioritized to strengthen memory retention.
          </p>
          <div className="mt-2.5 pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px] text-slate-300">
            <span>Cards due for review</span>
            <span
              className={`font-semibold ${
                stats.cardsDueToday > 0 ? 'text-rose-400 font-bold' : 'text-emerald-400'
              }`}
            >
              {stats.cardsDueToday}
            </span>
          </div>
        </div>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* FOOTER */}
      {/* --------------------------------------------------------------------- */}
      <div className="p-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span>RecallMate AI</span>
        <span>Local Storage</span>
      </div>
    </aside>
  );
};
