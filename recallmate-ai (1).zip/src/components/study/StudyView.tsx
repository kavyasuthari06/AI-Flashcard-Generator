/**
 * @file StudyView.tsx
 * @description Interactive flashcard study and spaced repetition revision view for RecallMate AI.
 * 
 * Features:
 * - Shows question first, reveals answer via a prominent "Show Answer" button or card flip
 * - Previous, Next, and Flip Card controls with keyboard navigation (Space, Arrow keys, 1-3)
 * - Repeated review workflow with a prominent "Review Again" option upon deck completion
 * - Three learning categories: Unrecalled, Need Practice, and Easy (highlighted with #2563EB blue theme)
 * - Dynamic category filtering: review only Unrecalled, Need Practice, Easy, or All cards
 * - In-place editing of questions and answers with Save and Cancel buttons
 * - Individual card deletion with a confirmation modal
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Shuffle,
  RotateCw,
  Plus,
  Trash2,
  Edit3,
  Check,
  CheckCircle2,
  Sparkles,
  Layers,
  Flame,
  Filter,
  Eye,
  EyeOff,
  RotateCcw,
} from 'lucide-react';
import { Deck, Flashcard, RecallRating } from '../../types';
import { normalizeRating } from '../../utils/storage';

interface StudyViewProps {
  // Active deck being studied
  deck: Deck;
  // Optional initial filter if opened from a category button (e.g. 'unrecalled')
  initialCategoryFilter?: 'unrecalled' | 'practice' | 'easy' | 'all';
  // Callback when deck content is updated
  onSaveDeck: (updatedDeck: Deck) => void;
  // Callback when a card is classified into a category
  onRateRecall: (deckId: string, cardId: string, rating: RecallRating) => void;
  // Callback to launch quiz mode for this deck
  onStartQuiz: (deck: Deck) => void;
  // Callback to navigate back to decks library
  onBack: () => void;
}

export const StudyView: React.FC<StudyViewProps> = ({
  deck,
  initialCategoryFilter = 'all',
  onSaveDeck,
  onRateRecall,
  onStartQuiz,
  onBack,
}) => {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------

  // Active category filter for this study session
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<
    'unrecalled' | 'practice' | 'easy' | 'all'
  >(initialCategoryFilter);

  // Deck cards list
  const [cards, setCards] = useState<Flashcard[]>(deck.cards);

  // Current index within the filtered cards array
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // Card flip state: false = Question side, true = Answer side
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  // Inline card edit modal/drawer
  const [isEditing, setIsEditing] = useState<boolean>(false);

  // New card creation modal
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Temporary success notification banner message
  const [saveBanner, setSaveBanner] = useState<string | null>(null);

  // Delete card confirmation modal
  const [showDeleteCardConfirm, setShowDeleteCardConfirm] = useState<boolean>(false);

  // Deck completion state (shown when reaching the end of cards)
  const [isSessionComplete, setIsSessionComplete] = useState<boolean>(false);

  // Edit fields
  const [editQuestion, setEditQuestion] = useState<string>('');
  const [editAnswer, setEditAnswer] = useState<string>('');
  const [editExplanation, setEditExplanation] = useState<string>('');
  const [editTopic, setEditTopic] = useState<string>('');

  // New custom card fields
  const [newQuestion, setNewQuestion] = useState<string>('');
  const [newAnswer, setNewAnswer] = useState<string>('');
  const [newExplanation, setNewExplanation] = useState<string>('');
  const [newTopic, setNewTopic] = useState<string>('');

  // Sync internal cards state when deck prop updates
  useEffect(() => {
    setCards(deck.cards);
  }, [deck]);

  /**
   * Filter cards based on selected learning category
   */
  const filteredCards = useMemo(() => {
    if (activeCategoryFilter === 'all') {
      return cards;
    }
    return cards.filter(
      (c) => normalizeRating(c.recallRating) === activeCategoryFilter
    );
  }, [cards, activeCategoryFilter]);

  // Ensure index remains in bounds when filtered cards change
  useEffect(() => {
    if (currentIndex >= filteredCards.length) {
      setCurrentIndex(Math.max(0, filteredCards.length - 1));
    }
    setIsFlipped(false);
  }, [filteredCards.length]);

  // Current active flashcard
  const currentCard = filteredCards[currentIndex];

  /**
   * Displays temporary feedback notification banner
   */
  const triggerBanner = (message: string) => {
    setSaveBanner(message);
    setTimeout(() => setSaveBanner(null), 3000);
  };

  /**
   * Initializes editing for the current card
   */
  const startEditing = () => {
    if (!currentCard) return;
    setEditQuestion(currentCard.question);
    setEditAnswer(currentCard.answer);
    setEditExplanation(currentCard.explanation || '');
    setEditTopic(currentCard.topic || '');
    setIsEditing(true);
  };

  /**
   * Saves edits to current card and updates persistent storage
   */
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentCard) return;

    const updatedCards = cards.map((c) =>
      c.id === currentCard.id
        ? {
            ...c,
            question: editQuestion.trim() || c.question,
            answer: editAnswer.trim() || c.answer,
            explanation: editExplanation.trim(),
            topic: editTopic.trim() || c.topic,
          }
        : c
    );

    setCards(updatedCards);
    setIsEditing(false);
    onSaveDeck({ ...deck, cards: updatedCards });
    triggerBanner('Changes saved successfully.');
  };

  /**
   * Confirms and deletes the current flashcard from the deck
   */
  const handleConfirmDeleteCard = () => {
    if (!currentCard) return;

    const remainingCards = cards.filter((c) => c.id !== currentCard.id);
    setCards(remainingCards);
    onSaveDeck({ ...deck, cards: remainingCards });
    setShowDeleteCardConfirm(false);
    setIsFlipped(false);
    triggerBanner('Flashcard deleted from deck.');
  };

  /**
   * Adds a new custom card to the deck
   */
  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestion.trim() || !newAnswer.trim()) return;

    const newCard: Flashcard = {
      id: `custom-card-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      cardType: 'qa',
      question: newQuestion.trim(),
      answer: newAnswer.trim(),
      explanation: newExplanation.trim() || 'Custom flashcard.',
      topic: newTopic.trim() || deck.subject || 'Custom',
      difficulty: deck.difficulty,
      reviewsCount: 0,
      lastReviewedDate: null,
      recallRating: 'unreviewed', // Starts Unclassified until student reviews
      nextReviewDate: null,
      reviewHistory: [],
      streak: 0,
    };

    const updatedCards = [...cards, newCard];
    setCards(updatedCards);
    onSaveDeck({ ...deck, cards: updatedCards });
    setShowAddModal(false);
    setNewQuestion('');
    setNewAnswer('');
    setNewExplanation('');
    setNewTopic('');
    triggerBanner('New flashcard added.');
  };

  /**
   * Shuffles the card review order
   */
  const handleShuffle = () => {
    const shuffled = [...cards].sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setCurrentIndex(0);
    setIsFlipped(false);
    setIsSessionComplete(false);
    triggerBanner('Cards shuffled.');
  };

  /**
   * Navigates to next card, or triggers session complete screen if at the end
   */
  const handleNext = () => {
    if (currentIndex < filteredCards.length - 1) {
      setCurrentIndex((prev) => prev + 1);
      setIsFlipped(false);
    } else {
      setIsSessionComplete(true);
    }
  };

  /**
   * Navigates to previous card
   */
  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
      setIsFlipped(false);
      setIsSessionComplete(false);
    }
  };

  /**
   * "Review Again" action: resets index to 0 so the student can practice repeatedly
   */
  const handleReviewAgain = () => {
    setCurrentIndex(0);
    setIsFlipped(false);
    setIsSessionComplete(false);
    triggerBanner('Deck restarted. Happy learning!');
  };

  /**
   * Updates card's recall category (Unrecalled, Need Practice, Easy)
   */
  const handleSetCategory = (rating: RecallRating) => {
    // [CLEAR LINE COMMENT]: Early guard clause clearly prevents null pointer exceptions if currentCard is undefined
    if (!currentCard) return;

    // [CLEAR LINE COMMENT]: Clearly delegates persistence to parent storage callback
    onRateRecall(deck.id, currentCard.id, rating);

    // [CLEAR LINE COMMENT]: Functional state updater ensures immutable array transformation
    // mapping strictly the matching card ID while preserving all other cards unchanged
    setCards((prevCards) =>
      prevCards.map((c) =>
        c.id === currentCard.id
          ? {
              ...c,
              recallRating: normalizeRating(rating), // Clearly normalizes rating to ensure backward-compatibility
              reviewsCount: (c.reviewsCount || 0) + 1, // Clearly increments review counter safely
              lastReviewedDate: new Date().toISOString(), // Clearly stamps the review timestamp
            }
          : c
      )
    );

    // [CLEAR LINE COMMENT]: Clearly generates a user-friendly toast message based on selected rating
    triggerBanner(`Classified as "${rating === 'unrecalled' ? 'Unrecalled' : rating === 'practice' ? 'Need Practice' : 'Easy'}"`);
  };

  // ---------------------------------------------------------------------------
  // KEYBOARD NAVIGATION SHORTCUTS
  // ---------------------------------------------------------------------------
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // [CLEAR LINE COMMENT]: Guard clause clearly prevents hotkeys from triggering when student types into text fields
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      // [CLEAR LINE COMMENT]: Space bar clearly flips the card while preventing browser page scroll
      if (e.code === 'Space') {
        e.preventDefault();
        setIsFlipped((prev) => !prev);
      } else if (e.key === 'ArrowRight') {
        handleNext(); // Clearly advances to next card on right arrow
      } else if (e.key === 'ArrowLeft') {
        handlePrev(); // Clearly navigates to previous card on left arrow
      } else if (isFlipped) {
        // [CLEAR LINE COMMENT]: Number keys 1, 2, 3 clearly categorize the card once the answer is revealed
        if (e.key === '1') handleSetCategory('unrecalled');
        if (e.key === '2') handleSetCategory('practice');
        if (e.key === '3') handleSetCategory('easy');
      }
    };

    // [CLEAR LINE COMMENT]: Adds native window listener for smooth global hotkey handling
    window.addEventListener('keydown', handleKeyDown);

    // [CLEAR LINE COMMENT]: Cleanup function clearly removes listener to prevent memory leaks or duplicate handlers
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, isFlipped, isEditing, showAddModal, filteredCards.length]);

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* --------------------------------------------------------------------- */}
      {/* TOP HEADER & CONTROLS */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            title="Back to My Decks"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-bold text-slate-900">{deck.title}</h1>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700">
                {deck.subject}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              {deck.sourceFileName ? `Source: ${deck.sourceFileName} · ` : ''}
              {deck.cards.length} total cards
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleShuffle}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium transition-colors cursor-pointer"
            title="Shuffle card order"
          >
            <Shuffle className="w-3.5 h-3.5 text-slate-500" />
            <span>Shuffle</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-slate-500" />
            <span>Add Card</span>
          </button>

          <button
            onClick={() => onStartQuiz(deck)}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Quiz This Deck</span>
          </button>
        </div>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* NOTIFICATION BANNER */}
      {/* --------------------------------------------------------------------- */}
      {saveBanner && (
        <div className="p-3 rounded-xl bg-blue-50 border border-blue-200 text-blue-800 text-xs flex items-center gap-2 animate-fade-in font-medium">
          <Check className="w-4 h-4 text-blue-600 flex-shrink-0" />
          <span>{saveBanner}</span>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* CATEGORY FILTER TABS (Consistent Blue Theme #2563EB) */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 text-[11px] font-bold uppercase tracking-wider pl-1.5">
            Filter:
          </span>

          {/* All Cards Tab */}
          <button
            type="button"
            onClick={() => {
              setActiveCategoryFilter('all');
              setCurrentIndex(0);
              setIsSessionComplete(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeCategoryFilter === 'all'
                ? 'bg-blue-600 text-white border border-blue-600 shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300'
            }`}
          >
            All Cards ({cards.length})
          </button>

          {/* Unrecalled Tab */}
          <button
            type="button"
            onClick={() => {
              setActiveCategoryFilter('unrecalled');
              setCurrentIndex(0);
              setIsSessionComplete(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeCategoryFilter === 'unrecalled'
                ? 'bg-blue-600 text-white border border-blue-600 shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300'
            }`}
          >
            Unrecalled ({cards.filter((c) => normalizeRating(c.recallRating) === 'unrecalled').length})
          </button>

          {/* Need Practice Tab */}
          <button
            type="button"
            onClick={() => {
              setActiveCategoryFilter('practice');
              setCurrentIndex(0);
              setIsSessionComplete(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeCategoryFilter === 'practice'
                ? 'bg-blue-600 text-white border border-blue-600 shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300'
            }`}
          >
            Need Practice ({cards.filter((c) => normalizeRating(c.recallRating) === 'practice').length})
          </button>

          {/* Easy Tab */}
          <button
            type="button"
            onClick={() => {
              setActiveCategoryFilter('easy');
              setCurrentIndex(0);
              setIsSessionComplete(false);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeCategoryFilter === 'easy'
                ? 'bg-blue-600 text-white border border-blue-600 shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50 hover:text-blue-700 hover:border-blue-300'
            }`}
          >
            Easy ({cards.filter((c) => normalizeRating(c.recallRating) === 'easy').length})
          </button>
        </div>

        {/* Counter */}
        {filteredCards.length > 0 && !isSessionComplete && (
          <span className="text-xs text-slate-500 font-medium pr-2">
            Card {currentIndex + 1} of {filteredCards.length}
          </span>
        )}
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* SESSION COMPLETE VIEW (Provides "Review Again" Option) */}
      {/* --------------------------------------------------------------------- */}
      {isSessionComplete ? (
        <div className="bg-white rounded-2xl border border-slate-200/90 p-8 sm:p-10 shadow-xs text-center space-y-4 animate-fade-in">
          <div className="w-14 h-14 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>

          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Deck Session Complete!
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto">
              You reviewed all {filteredCards.length} cards in this category. Repetition strengthens neural pathways.
            </p>
          </div>

          {/* Review Again & Quiz Options */}
          <div className="pt-3 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={handleReviewAgain}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm hover:bg-blue-700 border border-blue-600 shadow-sm transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Review Again</span>
            </button>

            <button
              onClick={() => onStartQuiz(deck)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-slate-700 hover:text-blue-700 hover:bg-blue-50/60 border border-slate-200 font-semibold text-xs sm:text-sm transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Take Quiz</span>
            </button>

            <button
              onClick={onBack}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-slate-600 hover:bg-slate-100 border border-slate-200 text-xs font-semibold cursor-pointer"
            >
              Back to My Decks
            </button>
          </div>
        </div>
      ) : filteredCards.length === 0 ? (
        /* Empty category notification */
        <div className="bg-white rounded-2xl border border-dashed border-slate-200 p-10 text-center space-y-3">
          <Layers className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">
            No cards found in "{activeCategoryFilter}" category
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Review your cards and assign them to categories to populate this view.
          </p>
          <button
            onClick={() => setActiveCategoryFilter('all')}
            className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 cursor-pointer"
          >
            View All Cards
          </button>
        </div>
      ) : (
        /* ------------------------------------------------------------------- */
        /* MAIN FLASHCARD CARD */
        /* ------------------------------------------------------------------- */
        <div className="space-y-4">
          <div
            onClick={() => setIsFlipped(!isFlipped)}
            className={`min-h-[300px] sm:min-h-[340px] p-8 sm:p-10 rounded-2xl border transition-all duration-200 cursor-pointer flex flex-col justify-between shadow-xs select-none ${
              isFlipped
                ? 'bg-slate-900 text-white border-slate-800 ring-2 ring-blue-500/20'
                : 'bg-white text-slate-900 border-slate-200/90 hover:border-blue-300'
            }`}
          >
            {/* Card Header */}
            <div className="flex items-center justify-between text-xs pb-3 border-b border-inherit opacity-75">
              <div className="flex items-center gap-2">
                <span className="font-semibold">{currentCard.topic || deck.subject}</span>
                <span>·</span>
                <span className="font-semibold text-blue-500 uppercase text-[10px] tracking-wider">
                  {currentCard.cardType === 'concept' ? 'Concept & Key Points' : 'Q&A Card'}
                </span>
              </div>

              {/* Status Indicator */}
              <div className="text-[11px] font-mono tracking-wider uppercase">
                {isFlipped ? 'Answer & Explanation' : 'Question (Click or tap Space to flip)'}
              </div>
            </div>

            {/* Card Body: Question on front, Answer on back */}
            <div className="my-auto py-6">
              {!isFlipped ? (
                /* FRONT: QUESTION FIRST */
                <div className="space-y-3">
                  <span className="text-xs font-bold tracking-wider uppercase text-blue-600">
                    {currentCard.cardType === 'concept' ? 'Core Concept' : 'Question'}
                  </span>
                  <h2 className="text-xl sm:text-2xl font-bold leading-relaxed">
                    {currentCard.question}
                  </h2>
                </div>
              ) : (
                /* BACK: ANSWER & DETAILS */
                <div className="space-y-4 animate-fade-in">
                  <div>
                    <span className="text-xs font-bold tracking-wider uppercase text-blue-400">
                      {currentCard.cardType === 'concept' ? 'Concept Summary' : 'Answer'}
                    </span>
                    <h3 className="text-lg sm:text-xl font-bold text-white leading-relaxed mt-1">
                      {currentCard.answer}
                    </h3>
                  </div>

                  {/* Bulleted Key Points */}
                  {currentCard.keyPoints && currentCard.keyPoints.length > 0 && (
                    <div className="pt-3 border-t border-slate-800 space-y-1.5">
                      <span className="text-xs font-semibold text-blue-300 uppercase tracking-wider block">
                        Key Points:
                      </span>
                      <ul className="space-y-1 text-xs sm:text-sm text-slate-200">
                        {currentCard.keyPoints.map((point, pIdx) => (
                          <li key={pIdx} className="flex items-start gap-2">
                            <span className="text-blue-400 font-bold">•</span>
                            <span className="leading-relaxed">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Explanation */}
                  {currentCard.explanation && (
                    <div className="mt-2.5 pt-2.5 border-t border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
                      <span className="font-semibold text-slate-200">Explanation: </span>
                      {currentCard.explanation}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Card Bottom Toolbar */}
            <div
              className="flex items-center justify-between pt-3 border-t border-inherit text-xs opacity-85"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Edit and Delete Actions */}
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={startEditing}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                  title="Edit flashcard"
                >
                  <Edit3 className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => setShowDeleteCardConfirm(true)}
                  className="p-1.5 rounded-lg hover:bg-rose-50 text-slate-500 hover:text-rose-600 transition-colors cursor-pointer"
                  title="Delete flashcard"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Status Badge */}
              <div className="text-[11px] text-slate-400">
                {currentCard.recallRating === 'unreviewed' ? (
                  <span className="text-slate-400 italic">Unclassified</span>
                ) : (
                  <span className="font-medium capitalize text-blue-500">
                    Category: {normalizeRating(currentCard.recallRating) === 'unrecalled' ? 'Unrecalled' : currentCard.recallRating === 'practice' ? 'Need Practice' : 'Easy'}
                  </span>
                )}
              </div>

              {/* Flip Button (Show Answer / Show Question) */}
              <button
                type="button"
                onClick={() => setIsFlipped(!isFlipped)}
                className="font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1.5 cursor-pointer text-xs"
              >
                <RotateCw className="w-3.5 h-3.5" />
                <span>{isFlipped ? 'Show Question' : 'Show Answer'}</span>
              </button>
            </div>
          </div>

          {/* ----------------------------------------------------------------- */}
          {/* FLASHCARD LEARNING CATEGORIES (Requirement 5) */}
          {/* Unrecalled, Need Practice, Easy */}
          {/* Highlighted with consistent blue theme #2563EB when active */}
          {/* ----------------------------------------------------------------- */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-slate-600">
                Classify Your Recall:
              </span>
              <span className="text-[11px] text-slate-400">
                Hotkeys: 1 (Unrecalled), 2 (Need Practice), 3 (Easy)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* 1. Unrecalled Button */}
              <button
                type="button"
                onClick={() => handleSetCategory('unrecalled')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  normalizeRating(currentCard.recallRating) === 'unrecalled'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-600/30'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-xs mb-1">
                  <span>1. Unrecalled</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                      normalizeRating(currentCard.recallRating) === 'unrecalled'
                        ? 'bg-blue-500 text-white'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    High Priority
                  </span>
                </div>
                <p
                  className={`text-[11px] leading-tight ${
                    normalizeRating(currentCard.recallRating) === 'unrecalled'
                      ? 'text-blue-100'
                      : 'text-slate-500'
                  }`}
                >
                  Could not remember answer. Review again soon.
                </p>
              </button>

              {/* 2. Need Practice Button */}
              <button
                type="button"
                onClick={() => handleSetCategory('practice')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  currentCard.recallRating === 'practice'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-600/30'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-xs mb-1">
                  <span>2. Need Practice</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                      currentCard.recallRating === 'practice'
                        ? 'bg-blue-500 text-white'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    Medium
                  </span>
                </div>
                <p
                  className={`text-[11px] leading-tight ${
                    currentCard.recallRating === 'practice'
                      ? 'text-blue-100'
                      : 'text-slate-500'
                  }`}
                >
                  Remembered partially. Practice to build memory.
                </p>
              </button>

              {/* 3. Easy Button */}
              <button
                type="button"
                onClick={() => handleSetCategory('easy')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  currentCard.recallRating === 'easy'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-sm ring-2 ring-blue-600/30'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-xs mb-1">
                  <span>3. Easy</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                      currentCard.recallRating === 'easy'
                        ? 'bg-blue-500 text-white'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    Mastered
                  </span>
                </div>
                <p
                  className={`text-[11px] leading-tight ${
                    currentCard.recallRating === 'easy'
                      ? 'text-blue-100'
                      : 'text-slate-500'
                  }`}
                >
                  Remembered confidently and accurately.
                </p>
              </button>
            </div>
          </div>

          {/* ----------------------------------------------------------------- */}
          {/* NAVIGATION FOOTER (Previous, Next, Review Again) */}
          {/* ----------------------------------------------------------------- */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrev}
              disabled={currentIndex === 0}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            {/* Review Again button always available */}
            <button
              type="button"
              onClick={handleReviewAgain}
              className="text-xs font-semibold text-slate-500 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              title="Restart deck from first card"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Review Again</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 text-xs font-semibold shadow-xs transition-colors cursor-pointer"
            >
              <span>{currentIndex === filteredCards.length - 1 ? 'Finish Review' : 'Next'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* EDIT FLASHCARD MODAL */}
      {/* --------------------------------------------------------------------- */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-blue-600" />
                <span>Edit Flashcard</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Question / Concept Title
                </label>
                <textarea
                  rows={3}
                  value={editQuestion}
                  onChange={(e) => setEditQuestion(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Answer / Concept Summary
                </label>
                <textarea
                  rows={4}
                  value={editAnswer}
                  onChange={(e) => setEditAnswer(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Explanation (Optional)
                </label>
                <textarea
                  rows={2}
                  value={editExplanation}
                  onChange={(e) => setEditExplanation(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-semibold cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 font-semibold shadow-xs cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* ADD CARD MODAL */}
      {/* --------------------------------------------------------------------- */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-scale-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Plus className="w-4 h-4 text-blue-600" />
                <span>Add Custom Flashcard</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddCard} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Question / Concept
                </label>
                <textarea
                  rows={2}
                  value={newQuestion}
                  onChange={(e) => setNewQuestion(e.target.value)}
                  placeholder="Enter the question or concept name..."
                  className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-800"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Answer / Summary
                </label>
                <textarea
                  rows={3}
                  value={newAnswer}
                  onChange={(e) => setNewAnswer(e.target.value)}
                  placeholder="Enter the answer..."
                  className="w-full p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-800"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-semibold cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 font-semibold shadow-xs cursor-pointer"
                >
                  Add Card
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* DELETE SINGLE CARD CONFIRMATION MODAL */}
      {/* --------------------------------------------------------------------- */}
      {showDeleteCardConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center space-y-4 animate-scale-in">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900">
                Delete this flashcard?
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                This will permanently remove this card from "{deck.title}". This action cannot be undone.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteCardConfirm(false)}
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmDeleteCard}
                className="flex-1 px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 text-xs font-semibold shadow-xs cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
