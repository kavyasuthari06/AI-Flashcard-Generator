/**
 * @file ManageUnrecalledModal.tsx
 * @description Dedicated modal dialog for managing and deleting Unrecalled flashcards within a deck.
 * Features:
 * - Checkbox selection per card
 * - Live count display: "Selected: X"
 * - "Select All" and "Clear Selection" controls
 * - "Delete Selected" button with confirmation dialog
 * - Individual card delete button
 * - Quick reclassification to "Need Practice" or "Easy"
 * - Displays "No Unrecalled flashcards remaining." when empty
 */

import React, { useState } from 'react';
import {
  X,
  Trash2,
  CheckSquare,
  Square,
  AlertCircle,
  Check,
  CheckCircle2,
  RotateCw,
} from 'lucide-react';
import { Deck, Flashcard, RecallRating } from '../../types';
import { normalizeRating } from '../../utils/storage';

interface ManageUnrecalledModalProps {
  // The deck currently being managed
  deck: Deck;
  // Callback when modal is closed
  onClose: () => void;
  // Callback to delete specific card IDs from the deck
  onDeleteCards: (deckId: string, cardIds: string[]) => void;
  // Callback to reclassify a card to another category (e.g. Need Practice or Easy)
  onRecategorizeCard: (deckId: string, cardId: string, newRating: RecallRating) => void;
}

export const ManageUnrecalledModal: React.FC<ManageUnrecalledModalProps> = ({
  deck,
  onClose,
  onDeleteCards,
  onRecategorizeCard,
}) => {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------

  // Set of selected card IDs
  const [selectedCardIds, setSelectedCardIds] = useState<Set<string>>(new Set());

  // Tracks confirmation modal for batch or individual deletion
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [cardsPendingDeletion, setCardsPendingDeletion] = useState<string[]>([]);

  // Filter cards strictly to Unrecalled items belonging to this deck
  const unrecalledCards: Flashcard[] = deck.cards.filter(
    (card) => normalizeRating(card.recallRating) === 'unrecalled'
  );

  /**
   * Toggles the selection status of a single card checkbox
   */
  const handleToggleCard = (cardId: string) => {
    setSelectedCardIds((prev) => {
      const next = new Set(prev);
      if (next.has(cardId)) {
        next.delete(cardId);
      } else {
        next.add(cardId);
      }
      return next;
    });
  };

  /**
   * Selects all visible unrecalled cards
   */
  const handleSelectAll = () => {
    const allIds = new Set(unrecalledCards.map((c) => c.id));
    setSelectedCardIds(allIds);
  };

  /**
   * Clears all card selections
   */
  const handleClearSelection = () => {
    setSelectedCardIds(new Set());
  };

  /**
   * Prepares to delete all currently selected cards
   */
  const handlePromptDeleteSelected = () => {
    if (selectedCardIds.size === 0) return;
    setCardsPendingDeletion(Array.from(selectedCardIds));
    setShowConfirmModal(true);
  };

  /**
   * Prepares to delete a single card
   */
  const handlePromptDeleteSingle = (cardId: string) => {
    setCardsPendingDeletion([cardId]);
    setShowConfirmModal(true);
  };

  /**
   * Confirms and executes card deletion
   */
  const handleConfirmDelete = () => {
    if (cardsPendingDeletion.length > 0) {
      onDeleteCards(deck.id, cardsPendingDeletion);
      // Remove deleted cards from current selection set
      setSelectedCardIds((prev) => {
        const next = new Set(prev);
        cardsPendingDeletion.forEach((id) => next.delete(id));
        return next;
      });
      setCardsPendingDeletion([]);
      setShowConfirmModal(false);
    }
  };

  /**
   * Cancels pending deletion
   */
  const handleCancelDelete = () => {
    setCardsPendingDeletion([]);
    setShowConfirmModal(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        {/* ------------------------------------------------------------------- */}
        {/* MODAL HEADER */}
        {/* ------------------------------------------------------------------- */}
        <div className="p-5 sm:p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50/70">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-rose-700 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded-md">
                Unrecalled Cards
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {deck.title}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-1">
              Manage Unrecalled Flashcards
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Review, reclassify, or permanently delete cards you struggled to recall.
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ------------------------------------------------------------------- */}
        {/* SELECTION ACTION TOOLBAR */}
        {/* ------------------------------------------------------------------- */}
        {unrecalledCards.length > 0 && (
          <div className="px-5 py-3 border-b border-slate-200/80 bg-white flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3">
              <span className="font-bold text-slate-800">
                Selected: {selectedCardIds.size}
              </span>

              <button
                type="button"
                onClick={handleSelectAll}
                className="font-medium text-blue-600 hover:text-blue-800 transition-colors cursor-pointer"
              >
                Select All
              </button>

              {selectedCardIds.size > 0 && (
                <button
                  type="button"
                  onClick={handleClearSelection}
                  className="font-medium text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                >
                  Clear Selection
                </button>
              )}
            </div>

            {/* Delete Selected Button */}
            <button
              type="button"
              onClick={handlePromptDeleteSelected}
              disabled={selectedCardIds.size === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 text-white font-semibold hover:bg-rose-700 disabled:opacity-40 disabled:cursor-not-allowed border border-rose-600 shadow-xs transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Selected ({selectedCardIds.size})</span>
            </button>
          </div>
        )}

        {/* ------------------------------------------------------------------- */}
        {/* CARDS LIST BODY */}
        {/* ------------------------------------------------------------------- */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-3.5">
          {unrecalledCards.length === 0 ? (
            /* Empty state required by prompt */
            <div className="text-center py-16 space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                No Unrecalled flashcards remaining.
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                All flashcards in this deck have been mastered, moved to Need Practice/Easy, or removed.
              </p>
            </div>
          ) : (
            unrecalledCards.map((card, idx) => {
              const isSelected = selectedCardIds.has(card.id);

              return (
                <div
                  key={card.id}
                  className={`p-4 rounded-xl border transition-all flex items-start gap-3.5 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/40 ring-1 ring-blue-600'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  {/* Selection Checkbox */}
                  <button
                    type="button"
                    onClick={() => handleToggleCard(card.id)}
                    className="mt-0.5 text-blue-600 cursor-pointer flex-shrink-0"
                    aria-label={`Select card ${idx + 1}`}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-5 h-5 text-blue-600" />
                    ) : (
                      <Square className="w-5 h-5 text-slate-400 hover:text-slate-600" />
                    )}
                  </button>

                  {/* Card Content Summary */}
                  <div className="flex-1 space-y-1.5 min-w-0">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-400 text-[11px]">
                        Card #{idx + 1}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {card.topic}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900">
                      {card.question}
                    </h4>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {card.answer}
                    </p>

                    {/* Quick Move / Recategorize Controls */}
                    <div className="pt-2 flex flex-wrap items-center gap-2 text-[11px]">
                      <span className="text-slate-400">Move to:</span>

                      <button
                        type="button"
                        onClick={() => onRecategorizeCard(deck.id, card.id, 'practice')}
                        className="px-2 py-0.5 rounded-md border border-amber-200 bg-amber-50 text-amber-800 hover:bg-amber-100 transition-colors font-medium cursor-pointer"
                      >
                        Need Practice
                      </button>

                      <button
                        type="button"
                        onClick={() => onRecategorizeCard(deck.id, card.id, 'easy')}
                        className="px-2 py-0.5 rounded-md border border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 transition-colors font-medium cursor-pointer"
                      >
                        Easy
                      </button>
                    </div>
                  </div>

                  {/* Individual Delete Button */}
                  <button
                    type="button"
                    onClick={() => handlePromptDeleteSingle(card.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer flex-shrink-0"
                    title="Delete this card"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* ------------------------------------------------------------------- */}
        {/* MODAL FOOTER */}
        {/* ------------------------------------------------------------------- */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            {unrecalledCards.length} total unrecalled cards in deck
          </span>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 text-xs font-semibold transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* CONFIRMATION MODAL FOR DELETION */}
      {/* --------------------------------------------------------------------- */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-60 bg-slate-900/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center space-y-4 animate-scale-in">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900">
                Confirm Deletion
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Are you sure you want to delete {cardsPendingDeletion.length}{' '}
                {cardsPendingDeletion.length === 1 ? 'flashcard' : 'flashcards'}?
                This will permanently remove {cardsPendingDeletion.length === 1 ? 'it' : 'them'} from your deck.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-3">
              <button
                type="button"
                onClick={handleCancelDelete}
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
