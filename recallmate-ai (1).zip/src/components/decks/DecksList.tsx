/**
 * @file DecksList.tsx
 * @description My Flashcards / My Decks library view for RecallMate AI.
 * Displays all saved decks with:
 * - Deck titles, source file or topic, and total card counts
 * - Three separate category buttons: Unrecalled (N), Need Practice (N), and Easy (N)
 * - "Manage Unrecalled" button opening a dedicated batch-deletion & reclassification modal
 * - Study, Quiz, Rename, and Delete deck actions with confirmation dialogs
 * - Dynamic filtering by subject and search query
 */

import React, { useState } from 'react';
import {
  Layers,
  Search,
  BookOpen,
  Edit2,
  Trash2,
  Filter,
  Check,
  Plus,
  Flame,
  FileText,
  Compass,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { Deck, RecallRating } from '../../types';
import { getDeckCategoryCounts } from '../../utils/storage';
import { ManageUnrecalledModal } from './ManageUnrecalledModal';

interface DecksListProps {
  // All decks in user storage
  decks: Deck[];
  // Opens deck in study view, optionally filtered to a specific category
  onOpenDeck: (deck: Deck, categoryFilter?: 'unrecalled' | 'practice' | 'easy' | 'all') => void;
  // Launches quiz mode for the deck
  onStartQuiz: (deck: Deck) => void;
  // Renames a deck
  onRenameDeck: (deckId: string, newTitle: string) => void;
  // Deletes an entire deck
  onDeleteDeck: (deckId: string) => void;
  // Deletes specific cards from a deck
  onDeleteCardsFromDeck?: (deckId: string, cardIds: string[]) => void;
  // Recategorizes a single card in a deck
  onRecategorizeCard?: (deckId: string, cardId: string, newRating: RecallRating) => void;
  // Navigates to creation view
  onCreateNew: () => void;
}

export const DecksList: React.FC<DecksListProps> = ({
  decks,
  onOpenDeck,
  onStartQuiz,
  onRenameDeck,
  onDeleteDeck,
  onDeleteCardsFromDeck = () => {},
  onRecategorizeCard = () => {},
  onCreateNew,
}) => {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------

  // Search input query
  const [searchQuery, setSearchQuery] = useState('');

  // Selected academic subject filter
  const [selectedSubject, setSelectedSubject] = useState<string>('all');

  // Inline deck renaming states
  const [renamingDeckId, setRenamingDeckId] = useState<string | null>(null);
  const [newTitleInput, setNewTitleInput] = useState('');

  // Entire deck delete confirmation modal
  const [deckPendingDeletionId, setDeckPendingDeletionId] = useState<string | null>(null);

  // Deck currently open in the Manage Unrecalled modal
  const [managingUnrecalledDeck, setManagingUnrecalledDeck] = useState<Deck | null>(null);

  // Extract unique subjects for dropdown filter
  const subjects = Array.from(new Set(decks.map((d) => d.subject))).filter(Boolean);

  // Filter decks based on search query and selected subject
  const filteredDecks = decks.filter((deck) => {
    const matchesSearch =
      deck.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      deck.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (deck.sourceFileName && deck.sourceFileName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (deck.sourceTopic && deck.sourceTopic.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesSubject = selectedSubject === 'all' || deck.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  /**
   * Begins inline deck rename
   */
  const handleStartRename = (deck: Deck) => {
    setRenamingDeckId(deck.id);
    setNewTitleInput(deck.title);
  };

  /**
   * Saves renamed deck title
   */
  const handleSaveRename = (deckId: string) => {
    if (newTitleInput.trim()) {
      onRenameDeck(deckId, newTitleInput.trim());
    }
    setRenamingDeckId(null);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-10">
      {/* --------------------------------------------------------------------- */}
      {/* HEADER */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-blue-600" />
            <span>My Flashcard Decks</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Review your cards by category (Unrecalled, Need Practice, Easy), take quizzes, or manage cards.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs sm:text-sm font-semibold hover:bg-blue-700 border border-blue-600 shadow-sm transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Deck</span>
        </button>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* SEARCH AND FILTERS TOOLBAR */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200/90 shadow-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search decks by title, subject, or source file..."
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
          />
        </div>

        {subjects.length > 0 && (
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="text-xs p-2 rounded-lg border border-slate-200 bg-white text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
            >
              <option value="all">All Subjects ({decks.length})</option>
              {subjects.map((sub) => (
                <option key={sub} value={sub}>
                  {sub}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* DECKS GRID */}
      {/* --------------------------------------------------------------------- */}
      {filteredDecks.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-200 space-y-3">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">
            {searchQuery ? 'No matching decks found' : 'No flashcard decks yet'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {searchQuery
              ? 'Try modifying your search keywords or clearing the subject filter.'
              : 'Convert your lecture notes, documents, or study topics into flashcards to start learning.'}
          </p>
          <div className="pt-2">
            <button
              onClick={onCreateNew}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 border border-blue-600 shadow-sm cursor-pointer"
            >
              Create Deck Now
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredDecks.map((deck) => {
            // Compute dynamic category counts directly from this deck's saved cards
            const categoryCounts = getDeckCategoryCounts(deck);
            const isRenaming = renamingDeckId === deck.id;

            return (
              <div
                key={deck.id}
                className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  {/* Subject and Difficulty Header */}
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-md">
                      {deck.subject}
                    </span>
                    <span className="text-slate-400 text-[11px] font-medium">
                      {deck.difficulty}
                    </span>
                  </div>

                  {/* Title & Inline Rename */}
                  {isRenaming ? (
                    <div className="flex items-center gap-1.5 pt-1">
                      <input
                        type="text"
                        value={newTitleInput}
                        onChange={(e) => setNewTitleInput(e.target.value)}
                        className="text-xs p-1.5 rounded-lg border border-blue-500 w-full focus:outline-none"
                        autoFocus
                      />
                      <button
                        onClick={() => handleSaveRename(deck.id)}
                        className="p-1.5 rounded-lg bg-blue-600 text-white text-xs cursor-pointer"
                        title="Save title"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between gap-2">
                      <h3
                        onClick={() => onOpenDeck(deck, 'all')}
                        className="text-sm font-bold text-slate-900 hover:text-blue-600 transition-colors cursor-pointer line-clamp-2"
                      >
                        {deck.title}
                      </h3>
                      <button
                        onClick={() => handleStartRename(deck)}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
                        title="Rename deck"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Source metadata & card count */}
                  <div className="text-[11px] text-slate-500 space-y-1">
                    <div className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-semibold text-slate-700">{deck.cards.length} cards</span>
                      <span>·</span>
                      <span className="capitalize">{deck.cardTypeMode || 'mixed'}</span>
                    </div>

                    {deck.sourceFileName && (
                      <div className="flex items-center gap-1.5 text-slate-400 truncate">
                        <FileText className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">File: {deck.sourceFileName}</span>
                      </div>
                    )}

                    {deck.sourceTopic && !deck.sourceFileName && (
                      <div className="flex items-center gap-1.5 text-slate-400 truncate">
                        <Compass className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">Topic: {deck.sourceTopic}</span>
                      </div>
                    )}
                  </div>

                  {/* ------------------------------------------------------------- */}
                  {/* SEPARATE CATEGORY BUTTONS (Requirement 6) */}
                  {/* Displays Unrecalled (N), Need Practice (N), and Easy (N) */}
                  {/* Clicking opens a separate view showing only cards in that category */}
                  {/* ------------------------------------------------------------- */}
                  <div className="pt-2 border-t border-slate-100 space-y-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                      Review by Category:
                    </span>

                    <div className="grid grid-cols-3 gap-1.5">
                      {/* 1. Unrecalled (N) Button */}
                      <button
                        type="button"
                        onClick={() => onOpenDeck(deck, 'unrecalled')}
                        className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-200 transition-colors text-center cursor-pointer"
                        title="Review cards you struggled to recall"
                      >
                        Unrecalled ({categoryCounts.unrecalled})
                      </button>

                      {/* 2. Need Practice (N) Button */}
                      <button
                        type="button"
                        onClick={() => onOpenDeck(deck, 'practice')}
                        className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 transition-colors text-center cursor-pointer"
                        title="Review partially remembered cards"
                      >
                        Need Practice ({categoryCounts.practice})
                      </button>

                      {/* 3. Easy (N) Button */}
                      <button
                        type="button"
                        onClick={() => onOpenDeck(deck, 'easy')}
                        className="py-1.5 px-2 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 transition-colors text-center cursor-pointer"
                        title="Review mastered cards"
                      >
                        Easy ({categoryCounts.easy})
                      </button>
                    </div>

                    {/* Manage Unrecalled Button (Requirement 7) */}
                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => setManagingUnrecalledDeck(deck)}
                        className="w-full py-1.5 px-3 rounded-lg text-xs font-medium bg-slate-50 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-200 hover:border-rose-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                        <span>Manage Unrecalled ({categoryCounts.unrecalled})</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* ------------------------------------------------------------- */}
                {/* FOOTER ACTION BUTTONS */}
                {/* ------------------------------------------------------------- */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  {/* Study All Cards */}
                  <button
                    onClick={() => onOpenDeck(deck, 'all')}
                    className="flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 border border-blue-600 shadow-xs transition-colors text-center cursor-pointer"
                  >
                    Study Cards
                  </button>

                  {/* Take Quiz */}
                  <button
                    onClick={() => onStartQuiz(deck)}
                    className="flex-1 py-1.5 px-3 rounded-lg text-xs font-semibold bg-white text-slate-700 hover:text-blue-700 hover:bg-blue-50/60 border border-slate-200 transition-colors text-center cursor-pointer"
                  >
                    Take Quiz
                  </button>

                  {/* Delete Entire Deck Button */}
                  <button
                    onClick={() => setDeckPendingDeletionId(deck.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                    title="Delete entire deck"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* MANAGE UNRECALLED FLASHCARDS MODAL (Requirement 7) */}
      {/* --------------------------------------------------------------------- */}
      {managingUnrecalledDeck && (
        <ManageUnrecalledModal
          deck={managingUnrecalledDeck}
          onClose={() => setManagingUnrecalledDeck(null)}
          onDeleteCards={(deckId, cardIds) => {
            onDeleteCardsFromDeck(deckId, cardIds);
            // Refresh modal deck reference
            const updated = decks.find((d) => d.id === deckId);
            setManagingUnrecalledDeck(updated || null);
          }}
          onRecategorizeCard={(deckId, cardId, newRating) => {
            onRecategorizeCard(deckId, cardId, newRating);
            const updated = decks.find((d) => d.id === deckId);
            setManagingUnrecalledDeck(updated || null);
          }}
        />
      )}

      {/* --------------------------------------------------------------------- */}
      {/* CONFIRM DELETE ENTIRE DECK MODAL */}
      {/* --------------------------------------------------------------------- */}
      {deckPendingDeletionId && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 text-center space-y-4 animate-scale-in">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900">Delete this deck?</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                This will permanently delete this deck and all its flashcards. This action cannot be undone.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-3">
              <button
                onClick={() => setDeckPendingDeletionId(null)}
                className="flex-1 px-4 py-2 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
              >
                Cancel
              </button>

              <button
                onClick={() => {
                  onDeleteDeck(deckPendingDeletionId);
                  setDeckPendingDeletionId(null);
                }}
                className="flex-1 px-4 py-2 rounded-xl bg-rose-600 text-white hover:bg-rose-700 text-xs font-semibold shadow-xs cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
