/**
 * @file CreateDeck.tsx
 * @description Flashcard deck creation component for RecallMate AI.
 * Allows students to generate flashcards from:
 * 1. A typed study topic
 * 2. Uploaded documents: PDF (.pdf), Microsoft Word (.docx), or plain text (.txt, .md) up to 50MB
 * 3. Pasted lecture notes
 * 
 * Features:
 * - Supports large document chunking with live progress feedback
 * - Allows choosing card type: Concept & Key Points, Question & Answer, or Both
 * - Unified #2563EB blue selection theme for all options (counts, difficulty, styles)
 * - Clear error handling and retry controls
 */

import React, { useState } from 'react';
import {
  Sparkles,
  FileText,
  Upload,
  AlertCircle,
  CheckCircle,
  Eye,
  EyeOff,
  Loader2,
  BookOpen,
  HelpCircle,
  ListChecks,
  Compass,
} from 'lucide-react';
import {
  DifficultyLevel,
  Flashcard,
  FlashcardTypeMode,
  InputMode,
  QuestionStyle,
} from '../../types';
import { extractTextFromPdf } from '../../utils/pdfExtractor';
import { extractTextFromDocx } from '../../utils/docxExtractor';
import { requestFlashcardGeneration } from '../../utils/api';

interface CreateDeckProps {
  initialContent?: string;
  initialTitle?: string;
  initialSubject?: string;
  initialMode?: InputMode;
  onDeckCreated: (deckData: {
    title: string;
    subject: string;
    difficulty: DifficultyLevel;
    cardTypeMode: FlashcardTypeMode;
    cards: Flashcard[];
    sourceText: string;
    sourceFileName?: string;
    sourceTopic?: string;
  }) => void;
  onCancel: () => void;
}

export const CreateDeck: React.FC<CreateDeckProps> = ({
  initialContent = '',
  initialTitle = '',
  initialSubject = '',
  initialMode = 'topic',
  onDeckCreated,
  onCancel,
}) => {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------

  // Tracks active input source: 'topic', 'pdf' (or docx), 'paste'
  const [inputMode, setInputMode] = useState<InputMode>(
    initialContent.length > 50 ? 'paste' : initialMode
  );

  // Topic input value if generating directly from a topic
  const [topicInput, setTopicInput] = useState<string>(
    initialMode === 'topic' ? initialTitle || initialSubject : ''
  );

  // Extracted or pasted study notes text
  const [content, setContent] = useState<string>(initialContent);

  // Custom deck title
  const [deckTitle, setDeckTitle] = useState<string>(initialTitle);

  // Academic subject or module tag
  const [subject, setSubject] = useState<string>(initialSubject);

  // Flashcard type mode: 'concept' (Key Points), 'qa' (Questions), or 'both'
  const [cardTypeMode, setCardTypeMode] = useState<FlashcardTypeMode>('both');

  // Flashcard count selection (5, 10, 15, or 20)
  const [cardCount, setCardCount] = useState<number>(10);

  // Target difficulty level: Beginner (Easy), Intermediate (Medium), Advanced (Hard)
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('Intermediate');

  // Question style focus: Mixed, Definitions, Conceptual, or Formula-based
  const [style, setStyle] = useState<QuestionStyle>('Mixed');

  // Document metadata states
  const [fileName, setFileName] = useState<string | null>(null);
  const [fileSizeFormatted, setFileSizeFormatted] = useState<string | null>(null);
  const [pageCount, setPageCount] = useState<number | null>(null);
  const [showExtractedPreview, setShowExtractedPreview] = useState(false);

  // Loading and progress feedback states
  const [isExtracting, setIsExtracting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [generationPercent, setGenerationPercent] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  /**
   * Formats raw byte sizes into clean, human-readable strings (e.g., '3.2 MB')
   */
  const formatBytes = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  /**
   * Handles document upload (PDF, DOCX, TXT, MD) with client-side text extraction.
   * Validates file size against the 50MB limit.
   */
  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const lowerName = file.name.toLowerCase();
    const isPdf = lowerName.endsWith('.pdf') || file.type === 'application/pdf';
    const isDocx =
      lowerName.endsWith('.docx') ||
      file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    const isText = lowerName.endsWith('.txt') || lowerName.endsWith('.md') || file.type.startsWith('text/');

    if (!isPdf && !isDocx && !isText) {
      setErrorMessage('Unsupported document format. Please upload a PDF (.pdf), Word document (.docx), or Text file (.txt).');
      return;
    }

    // [CLEAR LINE COMMENT]: 50MB file size limit clearly guards against client memory exhaustion
    const maxSizeBytes = 50 * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setErrorMessage(`File exceeds the 50MB limit (${formatBytes(file.size)}). Please choose a smaller document.`);
      return; // Clearly halts processing before reading excessive binary data
    }

    setIsExtracting(true); // Clearly informs UI that document parsing has begun
    setErrorMessage(null); // Clearly clears previous error banners

    try {
      if (isPdf) {
        // [CLEAR LINE COMMENT]: Delegates binary PDF stream parsing to pdfjs-dist cleanly
        const result = await extractTextFromPdf(file);
        setContent(result.text); // Clearly populates state with extracted plain text
        setFileName(file.name); // Clearly records file name for deck metadata
        setFileSizeFormatted(formatBytes(file.size)); // Clearly provides formatted size string (e.g., '2.4 MB')
        setPageCount(result.numPages); // Clearly sets page count badge
        if (!deckTitle) setDeckTitle(result.titleSuggestion); // Clearly suggests title if student hasn't entered one
        if (!subject) setSubject('Document Study'); // Clearly sets sensible default subject
      } else if (isDocx) {
        // [CLEAR LINE COMMENT]: Extracts clean document body from Word docx using mammoth
        const result = await extractTextFromDocx(file);
        setContent(result.text);
        setFileName(file.name);
        setFileSizeFormatted(formatBytes(file.size));
        setPageCount(null);
        if (!deckTitle) setDeckTitle(result.titleSuggestion);
        if (!subject) setSubject('Document Study');
      } else if (isText) {
        // [CLEAR LINE COMMENT]: Reads plain text UTF-8 stream directly using Web File API
        const rawText = await file.text();
        if (rawText.trim().length < 15) {
          throw new Error('The text file appears to be empty or contains insufficient content.');
        }
        setContent(rawText);
        setFileName(file.name);
        setFileSizeFormatted(formatBytes(file.size));
        setPageCount(null);
        // [CLEAR LINE COMMENT]: Clean regex strips file extension and replaces separators with readable spaces
        const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        if (!deckTitle) setDeckTitle(cleanName);
        if (!subject) setSubject('General Study');
      }
    } catch (err: any) {
      console.error('File extraction error:', err);
      setErrorMessage(
        err?.message || 'Failed to extract text from the file. Please ensure the document is not password-protected or corrupted.'
      );
      setContent('');
      setFileName(null);
      setFileSizeFormatted(null);
    } finally {
      setIsExtracting(false);
    }
  };

  /**
   * Initiates flashcard synthesis using Google Gemini AI.
   * Handles single-request and multi-chunk requests for large documents.
   */
  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const trimmedTopic = topicInput.trim();
    const trimmedContent = content.trim();

    // Input validation
    if (inputMode === 'topic' && trimmedTopic.length < 2) {
      setErrorMessage('Please enter a study topic to generate flashcards.');
      return;
    }

    if (inputMode !== 'topic' && trimmedContent.length < 15) {
      setErrorMessage('Please provide notes or document content with at least 15 characters before generating.');
      return;
    }

    const titleToUse =
      deckTitle.trim() ||
      (inputMode === 'topic' ? `${trimmedTopic} Flashcards` : 'Study Deck');
    const subjectToUse =
      subject.trim() ||
      (inputMode === 'topic' ? trimmedTopic : 'General Notes');

    setIsGenerating(true);
    setGenerationStep('Preparing study materials for Gemini AI...');
    setGenerationPercent(10);

    try {
      const generatedCards = await requestFlashcardGeneration({
        inputMode,
        topic: inputMode === 'topic' ? trimmedTopic : undefined,
        content: inputMode === 'topic' ? trimmedTopic : trimmedContent,
        cardTypeMode,
        count: cardCount,
        difficulty,
        style,
        subject: subjectToUse,
        deckTitle: titleToUse,
        onProgress: (stepMessage, percent) => {
          setGenerationStep(stepMessage);
          setGenerationPercent(percent);
        },
      });

      if (!generatedCards || generatedCards.length === 0) {
        throw new Error('AI returned an empty flashcard set. Please refine your notes or topic.');
      }

      // Notify parent component of newly created deck
      onDeckCreated({
        title: titleToUse,
        subject: subjectToUse,
        difficulty,
        cardTypeMode,
        cards: generatedCards,
        sourceText: inputMode === 'topic' ? `Topic: ${trimmedTopic}` : trimmedContent,
        sourceFileName: fileName || undefined,
        sourceTopic: inputMode === 'topic' ? trimmedTopic : undefined,
      });
    } catch (err: any) {
      console.error('Generation error:', err);
      setErrorMessage(
        err?.message || 'Failed to generate flashcards with Gemini AI. Please check your notes and try again.'
      );
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
      setGenerationPercent(0);
    }
  };

  // Difficulty options mapped to student-friendly labels
  const difficultyOptions: { level: DifficultyLevel; label: string }[] = [
    { level: 'Beginner', label: 'Easy' },
    { level: 'Intermediate', label: 'Medium' },
    { level: 'Advanced', label: 'Hard' },
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-10">
      {/* --------------------------------------------------------------------- */}
      {/* HEADER */}
      {/* --------------------------------------------------------------------- */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-600" />
            <span>Create Flashcards</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Turn your study topic, PDF, Word document, or notes into high-yield flashcards with Gemini AI.
          </p>
        </div>

        <button
          onClick={onCancel}
          className="text-xs font-semibold px-3.5 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-blue-700 hover:border-blue-300 transition-colors cursor-pointer"
        >
          Cancel
        </button>
      </div>

      {/* --------------------------------------------------------------------- */}
      {/* ERROR BANNER */}
      {/* --------------------------------------------------------------------- */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-semibold">Notice</h4>
            <p className="mt-0.5 text-rose-700 leading-relaxed">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* --------------------------------------------------------------------- */}
      {/* CONFIGURATION FORM */}
      {/* --------------------------------------------------------------------- */}
      <form onSubmit={handleGenerate} className="bg-white p-6 sm:p-7 rounded-2xl border border-slate-200/90 shadow-xs space-y-7">
        {/* STEP 1: SELECT INPUT SOURCE */}
        <div className="space-y-3">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
            1. Select Input Source
          </label>

          <div className="grid grid-cols-3 gap-2.5 max-w-lg">
            <button
              type="button"
              onClick={() => {
                setInputMode('topic');
                setErrorMessage(null);
              }}
              className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                inputMode === 'topic'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
              }`}
            >
              <Compass className={`w-3.5 h-3.5 ${inputMode === 'topic' ? 'text-white' : 'text-slate-500'}`} />
              <span>Enter Topic</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setInputMode('pdf');
                setErrorMessage(null);
              }}
              className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                inputMode === 'pdf'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
              }`}
            >
              <Upload className={`w-3.5 h-3.5 ${inputMode === 'pdf' ? 'text-white' : 'text-slate-500'}`} />
              <span>Upload Document</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setInputMode('paste');
                setErrorMessage(null);
              }}
              className={`py-2.5 px-3 text-xs font-semibold rounded-xl border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                inputMode === 'paste'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
              }`}
            >
              <FileText className={`w-3.5 h-3.5 ${inputMode === 'paste' ? 'text-white' : 'text-slate-500'}`} />
              <span>Paste Notes</span>
            </button>
          </div>

          {/* TOPIC INPUT MODE */}
          {inputMode === 'topic' && (
            <div className="space-y-2 pt-1">
              <label className="block text-xs font-semibold text-slate-700">
                What study topic would you like to master?
              </label>
              <input
                type="text"
                value={topicInput}
                onChange={(e) => {
                  setTopicInput(e.target.value);
                  if (!deckTitle) setDeckTitle(`${e.target.value} Flashcards`);
                  if (!subject) setSubject(e.target.value);
                }}
                placeholder="e.g. Photosynthesis, Binary Search Trees, Cold War, Cell Division..."
                className="w-full text-xs sm:text-sm p-3.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
              />
              <p className="text-[11px] text-slate-500">
                AI will generate curriculum-accurate flashcards tailored to this exact topic.
              </p>
            </div>
          )}

          {/* DOCUMENT UPLOAD MODE (PDF, DOCX, TXT) */}
          {inputMode === 'pdf' && (
            <div className="space-y-3 pt-1">
              <div className="border-2 border-dashed border-slate-200 hover:border-blue-400 rounded-xl p-6 text-center bg-slate-50/50 transition-colors">
                <Upload className="w-8 h-8 text-blue-600 mx-auto mb-2 opacity-80" />
                <p className="text-xs font-semibold text-slate-800">
                  Select your PDF (.pdf), Word (.docx), or Text document
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5 mb-3">
                  Supports lecture notes, slide exports, and textbooks up to 50MB. Text is extracted locally in your browser.
                </p>
                <label className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 border border-blue-600 transition-colors cursor-pointer shadow-xs">
                  {isExtracting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Extracting text...</span>
                    </>
                  ) : (
                    <>
                      <FileText className="w-3.5 h-3.5" />
                      <span>Choose Document (PDF / DOCX)</span>
                    </>
                  )}
                  <input
                    type="file"
                    accept=".pdf,.docx,.txt,.md,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    onChange={handleDocumentUpload}
                    disabled={isExtracting}
                    className="hidden"
                  />
                </label>
              </div>

              {/* Uploaded File Feedback */}
              {fileName && content && (
                <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-blue-900">
                    <CheckCircle className="w-4 h-4 text-blue-600 flex-shrink-0" />
                    <div>
                      <span className="font-semibold">{fileName}</span>
                      <span className="text-blue-700 ml-2">
                        ({fileSizeFormatted || ''} · {pageCount ? `${pageCount} pages · ` : ''}{content.length.toLocaleString()} characters)
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowExtractedPreview(!showExtractedPreview)}
                    className="text-xs font-medium text-blue-700 hover:text-blue-900 flex items-center gap-1 cursor-pointer"
                  >
                    {showExtractedPreview ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{showExtractedPreview ? 'Hide Text' : 'Review Text'}</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* PASTE NOTES MODE */}
          {inputMode === 'paste' && (
            <div className="space-y-1.5 pt-1">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Paste your lecture notes, summaries, or syllabus content:</span>
                <span>{content.length.toLocaleString()} characters</span>
              </div>
              <textarea
                rows={7}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Paste your notes here..."
                className="w-full text-xs font-mono p-3.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800 bg-slate-50/30"
              />
            </div>
          )}

          {/* Extracted Text Preview Drawer */}
          {showExtractedPreview && content && (
            <div className="p-4 rounded-xl bg-slate-900 text-slate-200 font-mono text-[11px] max-h-48 overflow-y-auto space-y-1">
              <div className="text-slate-400 text-[10px] uppercase font-bold tracking-wider mb-1">
                Extracted Text Preview:
              </div>
              <pre className="whitespace-pre-wrap leading-relaxed">{content}</pre>
            </div>
          )}
        </div>

        {/* STEP 2: FLASHCARD TYPE SELECTION */}
        <div className="pt-2 border-t border-slate-100 space-y-3">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
            2. Choose Flashcard Type
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Concept & Key Points */}
            <button
              type="button"
              onClick={() => setCardTypeMode('concept')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                cardTypeMode === 'concept'
                  ? 'border-blue-600 bg-blue-600 text-white shadow-md ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-white text-slate-800 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-900'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <ListChecks className={`w-4 h-4 ${cardTypeMode === 'concept' ? 'text-white' : 'text-slate-500'}`} />
                  <span className={`text-xs font-bold ${cardTypeMode === 'concept' ? 'text-white' : 'text-slate-900'}`}>
                    Concept & Key Points
                  </span>
                </div>
                <p className={`text-[11px] leading-relaxed ${cardTypeMode === 'concept' ? 'text-blue-100' : 'text-slate-500'}`}>
                  Focus on core concepts, definitions, and concise bulleted key takeaways.
                </p>
              </div>
              <span className={`text-[10px] font-semibold mt-2 ${cardTypeMode === 'concept' ? 'text-blue-200' : 'text-slate-400'}`}>
                Concept front · Key points back
              </span>
            </button>

            {/* Question & Answer */}
            <button
              type="button"
              onClick={() => setCardTypeMode('qa')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                cardTypeMode === 'qa'
                  ? 'border-blue-600 bg-blue-600 text-white shadow-md ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-white text-slate-800 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-900'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <HelpCircle className={`w-4 h-4 ${cardTypeMode === 'qa' ? 'text-white' : 'text-slate-500'}`} />
                  <span className={`text-xs font-bold ${cardTypeMode === 'qa' ? 'text-white' : 'text-slate-900'}`}>
                    Question & Answer
                  </span>
                </div>
                <p className={`text-[11px] leading-relaxed ${cardTypeMode === 'qa' ? 'text-blue-100' : 'text-slate-500'}`}>
                  Exam-oriented revision questions with accurate, direct answers and explanations.
                </p>
              </div>
              <span className={`text-[10px] font-semibold mt-2 ${cardTypeMode === 'qa' ? 'text-blue-200' : 'text-slate-400'}`}>
                Question front · Answer back
              </span>
            </button>

            {/* Both Types (Combined) */}
            <button
              type="button"
              onClick={() => setCardTypeMode('both')}
              className={`p-4 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                cardTypeMode === 'both'
                  ? 'border-blue-600 bg-blue-600 text-white shadow-md ring-2 ring-blue-600/30'
                  : 'border-slate-200 bg-white text-slate-800 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-900'
              }`}
            >
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <BookOpen className={`w-4 h-4 ${cardTypeMode === 'both' ? 'text-white' : 'text-slate-500'}`} />
                  <span className={`text-xs font-bold ${cardTypeMode === 'both' ? 'text-white' : 'text-slate-900'}`}>
                    Both Types (Combined)
                  </span>
                </div>
                <p className={`text-[11px] leading-relaxed ${cardTypeMode === 'both' ? 'text-blue-100' : 'text-slate-500'}`}>
                  A balanced combination of concept breakdowns and test questions.
                </p>
              </div>
              <span className={`text-[10px] font-semibold mt-2 ${cardTypeMode === 'both' ? 'text-blue-200' : 'text-slate-400'}`}>
                Comprehensive study set
              </span>
            </button>
          </div>
        </div>

        {/* STEP 3: DECK DETAILS & DIFFICULTY */}
        <div className="pt-2 border-t border-slate-100 space-y-4">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-500">
            3. Deck Details & Settings
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Deck Title
              </label>
              <input
                type="text"
                value={deckTitle}
                onChange={(e) => setDeckTitle(e.target.value)}
                placeholder={inputMode === 'topic' ? 'e.g. Photosynthesis Flashcards' : 'e.g. Chapter 4 Revision'}
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Subject / Tag
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="e.g. Biology, Computer Science, History"
                className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 text-slate-800"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
            {/* Number of Cards */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Number of Cards
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {[5, 10, 15, 20].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setCardCount(num)}
                    className={`py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                      cardCount === num
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                    }`}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty Level (Easy, Medium, Hard) */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Difficulty Level
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {difficultyOptions.map(({ level, label }) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setDifficulty(level)}
                    className={`py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer ${
                      difficulty === level
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Question Style Focus */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Style Focus
              </label>
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value as QuestionStyle)}
                className="w-full text-xs p-2 rounded-lg border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600"
              >
                <option value="Mixed">Mixed (Balanced)</option>
                <option value="Definitions">Definitions & Key Terms</option>
                <option value="Conceptual">Conceptual & Why/How</option>
                <option value="Formula-based">Formula-based & Rules</option>
              </select>
            </div>
          </div>
        </div>

        {/* SUBMIT BUTTON & SUMMARY */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            {inputMode === 'topic'
              ? topicInput.trim()
                ? `Ready to generate ~${cardCount} ${cardTypeMode === 'concept' ? 'concept' : cardTypeMode === 'qa' ? 'Q&A' : 'mixed'} cards for "${topicInput.trim()}".`
                : 'Enter a topic to generate flashcards.'
              : content.length > 0
              ? `Ready to synthesize ~${cardCount} flashcards from provided material (${content.length.toLocaleString()} characters).`
              : 'Upload a document or paste your notes above.'}
          </div>

          <button
            type="submit"
            disabled={
              isGenerating ||
              isExtracting ||
              (inputMode === 'topic' ? topicInput.trim().length < 2 : content.trim().length < 15)
            }
            className="inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm hover:bg-blue-700 border border-blue-600 disabled:opacity-40 disabled:cursor-not-allowed shadow-sm shadow-blue-600/20 transition-all cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Generating Flashcards...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Flashcards</span>
              </>
            )}
          </button>
        </div>

        {/* Live Multi-Chunk Progress Feedback */}
        {isGenerating && (
          <div className="p-4 rounded-xl bg-blue-50 border border-blue-100 space-y-2 animate-fade-in">
            <div className="flex items-center justify-between text-xs text-blue-900 font-semibold">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 text-blue-600 animate-spin flex-shrink-0" />
                <span>{generationStep || 'Processing with Gemini 3.8 Flash...'}</span>
              </div>
              <span>{generationPercent > 0 ? `${generationPercent}%` : ''}</span>
            </div>
            {generationPercent > 0 && (
              <div className="w-full h-1.5 bg-blue-200/60 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600 transition-all duration-300"
                  style={{ width: `${generationPercent}%` }}
                />
              </div>
            )}
          </div>
        )}
      </form>
    </div>
  );
};
